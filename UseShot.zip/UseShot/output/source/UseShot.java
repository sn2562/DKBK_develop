import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.spi.*; 
import ddf.minim.signals.*; 
import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.ugens.*; 
import ddf.minim.effects.*; 
import SimpleOpenNI.*; 
import java.awt.FileDialog; 
import java.io.*; 
import SimpleOpenNI.*; 
import java.io.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class UseShot extends PApplet {

//processing-java --run --sketch=/Users/kawasemi/Documents/Processing/DKBK_develop/UseShot --output=/Users/kawasemi/Documents/Processing/DKBK_develop/UseShot/output --force








//\u66f4\u65b0\u306e\u3058\u3069\u3046\u304b


String FilePath1;//\u59cb\u3081\u306b\u30ed\u30fc\u30c9\u3059\u308b\u30c7\u30fc\u30bf\u3068L\u30ad\u30fc\u62bc\u3057\u305f\u6642\u306b\u8aad\u3080\u30c7\u30fc\u30bf\u306e\u30d1\u30b9\u3092\u5165\u308c\u89e3\u304f\u305f\u3081\u306e\u3084\u3064(debug\u7528)
boolean debugMode=false;//\u30c7\u30d0\u30c3\u30af\u30e2\u30fc\u30c9\u304ctrue\u6642\u306f\u81ea\u52d5\u7684\u306b\u4e0a\u8a18\u306e\u30d5\u30a1\u30a4\u30eb\u3092\u30ed\u30fc\u30c9\u3059\u308b\u3002

final int K=2;//\u6df1\u5ea6\u30c7\u30fc\u30bf\u63cf\u5199\u306e\u7d30\u304b\u3055
final int LENGTH=1145;//\u30c7\u30d7\u30b9\u30c7\u30fc\u30bf\u3092\u683c\u7d0d\u3057\u3066\u3044\u308b\u914d\u5217\u306e\u5927\u304d\u3055
final int data_width=640;//\u753b\u50cf\u306e\u89e3\u50cf\u5ea6
final int data_height=480;//\u753b\u50cf\u306e\u89e3\u50cf\u5ea6

final float screenZoom=1;//1.8;//\u63cf\u753b\u7bc4\u56f2\u306e\u500d\u7387//1.5\u666e\u6bb5\u4f7f\u3044//1.2//\u5fae\u8abf\u6574\u7528

private TakeShot take;//\u30c7\u30fc\u30bf\u306e\u4fdd\u5b58\u306b\u5229\u7528
private Tool tool;//\u30c4\u30fc\u30eb\u30d0\u30fc
private boolean pmousePressed;

static ArrayList<Data> data;//\u6271\u3063\u3066\u3044\u308b\u30c7\u30fc\u30bf\u3092\u683c\u7d0d\u3057\u3066\u304a\u304f\u5834\u6240

static int setLineW;//\u7dda\u306e\u592a\u3055
static int animFrame;//\u30d5\u30ec\u30fc\u30e0\u30ec\u30fc\u30c8\u306b\u6cbf\u3063\u305f\u30d5\u30ec\u30fc\u30e0\u6570
static int frameset;//
static boolean animation;//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u3057\u3066\u3082\u3044\u3044\u304b\u3069\u3046\u304b
static int framecount=5;//\u8a2d\u5b9a\u3059\u308b\u30d5\u30ec\u30fc\u30e0\u30ab\u30a6\u30f3\u30c8

String Savepath ="";
private String dirName = "dsdData";
private String path = "";

Minim minim;//\u97f3
AudioPlayer song;

SimpleOpenNI context;//\u30ab\u30e1\u30e9\u66f4\u65b0\u7528
static int oldToolNumber;

//\u30ad\u30e3\u30f3\u30d0\u30b9\u8868\u793a\u7528
private PGraphics cv;

public String getParentFilePath(String path, int n) {//n\u968e\u5c64\u4e0a\u306e\u30d5\u30a1\u30a4\u30eb\u30d1\u30b9\u3092\u53d6\u5f97
	File f=new File(path);
	for (int i=0; i<n; i++)
		f=f.getParentFile();
	return f.getAbsolutePath();
}

public void setup() {
	animFrame=frameset=0;
	animation=false;

	oldToolNumber=0;
	context = new SimpleOpenNI(this);//\u30ab\u30e1\u30e9\u66f4\u65b0\u7528
	if (context.isInit() == false) {//\u30ab\u30e1\u30e9\u304c\u7e4b\u304c\u3089\u306a\u304b\u3063\u305f\u3089\u30c7\u30d0\u30c3\u30b0\u7528\u306e\u3092\u8aad\u307f\u8fbc\u3080
		println("Can't init SimpleOpenNI, maybe the camera is not connected!"); 
		println("\u30ab\u30e1\u30e9");
		debugMode=true;
	}

	context.setMirror(false);//\u93e1\u3067\u306f\u8868\u793a\u3057\u306a\u3044

	//OS\u30c1\u30a7\u30c3\u30af\u3068\u4fdd\u5b58\u30d1\u30b9\u306e\u8a2d\u5b9a
	String osname=System.getProperty("os.name").toUpperCase();

	if (osname.matches("^.*MAC.*")) {
		path = sketchPath+"/"+dirName;//Mac\u306e\u5834\u5408
		println("Mac");
	} else if (osname.matches("^.*WINDOWS.*")) {
		path = sketchPath+"/"+dirName;//Windows\u306e\u5834\u5408
		println("Win");
	} else{
		path = sketchPath+"/"+dirName;//Mac\u306e\u5834\u5408
	}
	File file = new File(path);
	println("path "+path);
	if (file.exists()) {
		System.out.println("\u65e2\u5b58\u306edsdData\u30c7\u30a3\u30ec\u30af\u30c8\u30ea\u3092\u4f7f\u7528");
	} else {
		System.out.println("dsdData\u30c7\u30a3\u30ec\u30af\u30c8\u30ea\u3092\u65b0\u3057\u304f\u4f5c\u6210");
		File newfile1 = new File(path);
		newfile1.mkdir();
	}
	Savepath = path+"/";


	frame.setTitle("DKBK");
	size(PApplet.parseInt(640*screenZoom), PApplet.parseInt(480*screenZoom), P3D);

	//\u7dda\u306e\u592a\u3055\u3001\u521d\u671f\u8a2d\u5b9a\u306f3
	setLineW=7;

	FilePath1=dataPath("")+"/todai_horiken7.dsd";

	tool=new Tool();//\u30c4\u30fc\u30eb\u30d0\u30fc
	take=new TakeShot(this);//\u30c6\u30a4\u30af\u30b7\u30e7\u30c3\u30c8

	//\u521d\u671f\u30c7\u30fc\u30bf\u306e\u8aad\u307f\u8fbc\u307f
	data=new ArrayList<Data>();
	if (debugMode) {
		data.add(new Data(FilePath1));//\u30c7\u30d0\u30c3\u30af\u7528\u306e\u30c7\u30fc\u30bf\u8aad\u307f\u8fbc\u307f
		//    data.get(1).changeDrawMode();
	} else {
		data.add(new Data(true));//\u7a7a\u306e\u30c7\u30fc\u30bf\u3092\u5165\u308c\u3066\u304a\u304f
	}
	//\u8868\u793a\u306b\u3064\u3044\u3066
	perspective(PI/4, PApplet.parseFloat(width)/PApplet.parseFloat(height), 10, 150000);//\u8996\u91ce\u89d2\u306f45\u5ea6
	float z0 = (height/2)/tan(PI/8);//tan(radian(45/2))\u3092\u4f7f\u3046\u3068\u3001\u5fae\u5999\u306b\u6570\u5b57\u304c\u30ba\u30ec\u308b\u306e\u3067\u30c0\u30e1
	//\u30ab\u30e1\u30e9\u306e\u4f4d\u7f6e\u3092\u6c7a\u3081\u308b
	camera(width/2, height/2, z0, width/2, height/2, 0, 0, 1, 0);

	pmousePressed=false;

	//\u97f3\u6e90
	minim = new Minim( this );
	song = minim.loadFile( "CameraFlash.wav" );
	
	cv = createGraphics(width, height, P3D);//Depth\u8868\u793a\u7528\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u4f5c\u6210
	z0 = (cv.height/2)/tan(PI/8);//tan(radian(45/2))\u3092\u4f7f\u3046\u3068\u3001\u5fae\u5999\u306b\u6570\u5b57\u304c\u30ba\u30ec\u308b\u306e\u3067\u30c0\u30e1
	cv.perspective(PI/4, PApplet.parseFloat(cv.width)/PApplet.parseFloat(cv.height), 10, 150000);//\u8996\u91ce\u89d2\u306f45\u5ea6
	cv.camera(cv.width/2, cv.height/2, z0, cv.width/2, cv.height/2, 0, 0, 1, 0);
}

public void draw() {

	frame.setTitle(data.get(tool.nowDataNumber).dataname+" "+round(frameRate));//
	//\u30d5\u30ec\u30fc\u30e0\u306e\u8a08\u7b97
	if (tool.animMode()) {
		//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u7528\u30d5\u30ec\u30fc\u30e0\u30ec\u30fc\u30c8
		animFrame++;
		frameset=(animFrame-1)/framecount;
		//\u8868\u793a\u3059\u308b\u30c7\u30fc\u30bf\u756a\u53f7\u3092\u51fa\u529b

		//tool.nowDataNumber\u3092\u5909\u66f4\u3059\u308b
		tool.nowDataNumber=frameset%data.size();
		//println(frameset+":"+tool.moveWriter);

		//\u8868\u793a\u3059\u308b\u30c7\u30fc\u30bf\u3092\u5909\u66f4\u3059\u308b draw_mode\u306f0~3
		for (int i=0; i<data.size (); i++) {
			if (i==tool.nowDataNumber)//\u9078\u629e\u4e2d\u306e\u30c7\u30fc\u30bf\u306a\u3089\u3070
				data.get(i).draw_mode=1;//0\u756a\u306e\u8868\u793a\u65b9\u6cd5\u306b\u3042\u308f\u305b\u3066\u8868\u793a
			else//\u305d\u308c\u4ee5\u5916
				data.get(i).draw_mode=3;//\u975e\u8868\u793a
		}
	}

	tool.update();//\u30c4\u30fc\u30eb\u30d0\u30fc\u3092\u66f4\u65b0

	background(252, 251, 246);//\u30ad\u30e3\u30f3\u30d0\u30b9\u80cc\u666f\u8272
	if (!tool.isDragged&&!tool.isDragged2){//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u306a\u3044\u306e\u306a\u3089
		data.get(tool.nowDataNumber).draw();//\u7dda\u3092\u63cf\u304f
	}

	if (tool.getMode()) {//true\u3067UseShotMode,false\u3067TakeShotMode
		context.update();//\u30ab\u30e1\u30e9\u66f4\u65b0\u7528
		//data\u5185\u306e\u30c7\u30fc\u30bf\u3092\u66f8\u304d\u63db\u3048\u308b
		// data.get(tool.nowDataNumber).cameraChangeUpdate();
		//todo
		//useshot\u7cfb\u30c7\u30fc\u30bf\u306e\u63cf\u753b
		data.get(tool.nowDataNumber).update();//\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u8868\u793a

		//\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u63cf\u753b
		cv.beginDraw();
		cv.background(252, 251, 246);//\u30ad\u30e3\u30f3\u30d0\u30b9\u80cc\u666f\u8272
		data.get(tool.nowDataNumber).updateDKBKCanvas(cv, context);//\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u8868\u793a
		cv.endDraw();

		for (int i=0; i<data.size (); i++) {//\u5404\u7a2e\u30c7\u30fc\u30bf\u306e\u64cd\u4f5c\u3068\u63cf\u753b
			//			data.get(i).update();

			if (tool.getMovMode()) {//true\u3067\u9759\u6b62\u753b\u30e2\u30fc\u30c9,false\u3067\u52d5\u753b\u30e2\u30fc\u30c9
			} else {
				take.draw();
				take.save();//\u66f4\u65b0\u3059\u308b
			}
		}
	} else {//takeshot
		take.draw();
	}


//	image(cv, 0, 0,cv.width/2,cv.height/2);//\u30ad\u30e3\u30f3\u30d0\u30b9\u3092\u63cf\u753b
	image(cv, 0, 0,cv.width,cv.height);//\u30ad\u30e3\u30f3\u30d0\u30b9\u3092\u63cf\u753b
	tool.draw();//\u30c4\u30fc\u30eb\u30d0\u30fc\u3092\u63cf\u753b


	pmousePressed=mousePressed;


}

public void mousePressed() {
	//\u691c\u8a3c\u7528
	//  println(tool.nowToolNumber);

	//\u5207\u308a\u66ff\u3048

	//\u7dda\u306e\u592a\u3055\u3092\u30da\u30f3\u306e\u30dc\u30bf\u30f3\u3067\u5909\u66f4\u3059\u308b
	setLineW=13;//\u305d\u308c\u4ee5\u5916\u306f\u7d30\u304f

	if (tool.getMode()) {
		if (!tool.pointOver(mouseX, mouseY)) {//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u306a\u3044\u306e\u306a\u3089
			data.get(tool.nowDataNumber).addLine();//\u7dda\u3092\u8ffd\u52a0
		}
	} else {//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u3044\u305f\u3089
		take.mousePressed();
	}

	if (tool.pointOver(mouseX, mouseY)) {//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u3044\u308b\u6642
		//println("\u91cd\u306a\u3063\u3066\u308b");
		/*
    if (oldToolNumber==tool.nowToolNumber) {//\u3082\u3057\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af\u306a\u3089\u3070
     println("\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af:number"+oldToolNumber);
     //data.get(tool.nowDataNumber).changeDrawMode();
     }
     */
	}
}

public void mouseReleased() {
	//\u56de\u8ee2\u64cd\u4f5c\u3092\u30ea\u30bb\u30c3\u30c8\u3059\u308b
	if ( mouseButton == RIGHT ) {
		if (!tool.moveWriter)
			data.get(tool.nowDataNumber).matrixReset();
		else
			tool.matrixReset();
	}
}

public void keyReleased(java.awt.event.KeyEvent e) {
	if (tool.getMode()) {
		super.keyReleased(e);//keyCode\u3084\u3089\u3092\u66f4\u65b0\u3059\u308b\u305f\u3081\u306b\u5fc5\u8981
		switch(e.getKeyCode()) {
			case LEFT:
			case UP:
			case RIGHT:
			case DOWN:
			case '0'://do
				//if (data.get(tool.nowDataNumber).moveAble())
				//data.get(tool.nowDataNumber).updateMap();//\u79fb\u52d5\u30dc\u30bf\u30f3\u3092\u96e2\u3057\u305f\u6642\u306b\u5c04\u5f71\u3057\u306a\u304a\u3059
		}
	}
}

//\u30de\u30a6\u30b9\u306e\u64cd\u4f5c
public void mouseDragged() {

	if ( mouseButton == RIGHT ) //\u53f3\u30dc\u30bf\u30f3\u304c\u62bc\u3055\u308c\u305f\u3068\u304d\u306b\u592a\u3055\u3092\u5909\u66f4\u3059\u308b
		setLineW=12;//\u305d\u308c\u4ee5\u5916\u306f\u7d30\u304f

	if ( mouseButton == RIGHT ) {//\u53f3\u30af\u30ea\u30c3\u30af\u3092\u3057\u3066\u3044\u305f\u3089
		//\u95b2\u89a7\u64cd\u4f5c
		//\u56de\u8ee2\u304b\u4e26\u884c\u304b\u3092\u5224\u5b9a\u3059\u308b
		if (!tool.moveMode) {
			//1.shift\u304c\u62bc\u3055\u308c\u3066\u3044\u308b\u304b\u53f3\u30af\u30ea\u30c3\u30af\u306a\u3089\u5e73\u884c\u79fb\u52d5
			//\u5e73\u884c\u79fb\u52d5
			if (!tool.moveWriter) {
				data.get(tool.nowDataNumber).move(mouseX-pmouseX, mouseY-pmouseY);
			} else {
				tool.move(mouseX-pmouseX, mouseY-pmouseY);
			}
		} else {
			//2.\u4f55\u3082\u306a\u3057\u306a\u3089\u56de\u8ee2\u79fb\u52d5
			//\u56de\u8ee2\u79fb\u52d5
			if (!tool.moveWriter) {//\u5168\u4f53\u79fb\u52d5
				data.get(tool.nowDataNumber).rotate(radians(pmouseX-mouseX)/10, radians(pmouseY-mouseY)/10, 0);
			} else {//\u500b\u3005
				tool.rotate(radians(pmouseX-mouseX)/10, radians(pmouseY-mouseY)/10, 0);
			}
		}
	} else {//\u305d\u308c\u4ee5\u5916
		//\u30c4\u30fc\u30eb\u3054\u3068\u306e\u8a2d\u5b9a
		if (tool.getMode()) {
			if (!tool.isDragged&&!tool.isDragged2)//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u306a\u3044\u306e\u306a\u3089
				switch(tool.nowToolNumber) {
					case 0://\u88dc\u6b63\u30da\u30f3
						//println("tool.nowToolNumber\u3092\u8868\u793a"+tool.nowToolNumber);
						//if ( mouseButton == RIGHT )
						//println("\u76f4\u7dda");
						//else
						data.get(tool.nowDataNumber).addPoint(mouseX, mouseY);
						break;
					case 1://\u30b9\u30d7\u30ec\u30fc\u6539
						data.get(tool.nowDataNumber).addPoint(mouseX, mouseY);
						break;
					case 2://\u30ab\u30c3\u30bf\u30fc
						data.get(tool.nowDataNumber).cutLine(pmouseX, pmouseY, mouseX, mouseY);
						break;
					case 4://\u79fb\u52d5
						//\u79fb\u52d5\u91cf\u3092\u51fa\u529b
						data.get(tool.nowDataNumber).printTR();
						//\u691c\u8a3c\u75282
						if (keyEvent==null) {//\u8d77\u52d5\u76f4\u5f8c
							//\u56de\u8ee2\u304b\u4e26\u884c\u304b\u3092\u5224\u5b9a\u3059\u308b
							if (!tool.moveMode) {
								//1.shift\u304c\u62bc\u3055\u308c\u3066\u3044\u308b\u304b\u53f3\u30af\u30ea\u30c3\u30af\u306a\u3089\u5e73\u884c\u79fb\u52d5
								//\u5e73\u884c\u79fb\u52d5
								if (!tool.moveWriter) {
									data.get(tool.nowDataNumber).move(mouseX-pmouseX, mouseY-pmouseY);
								} else {
									tool.move(mouseX-pmouseX, mouseY-pmouseY);
								}
							} else {
								//2.\u4f55\u3082\u306a\u3057\u306a\u3089\u56de\u8ee2\u79fb\u52d5
								//\u56de\u8ee2\u79fb\u52d5
								if (!tool.moveWriter) {//\u5168\u4f53\u79fb\u52d5
									data.get(tool.nowDataNumber).rotate(radians(pmouseX-mouseX)/10, radians(pmouseY-mouseY)/10, 0);
								} else {//\u500b\u3005
									tool.rotate(radians(pmouseX-mouseX)/10, radians(pmouseY-mouseY)/10, 0);
								}
							}
						} else if (keyEvent.isShiftDown()||!tool.moveMode) {
							//3.shift\u304c\u62bc\u3055\u308c\u3066\u3044\u308b\u304b\u53f3\u30af\u30ea\u30c3\u30af\u306a\u3089\u5e73\u884c\u79fb\u52d5
							//\u5e73\u884c\u79fb\u52d5
							if (!tool.moveWriter) {
								data.get(tool.nowDataNumber).move(mouseX-pmouseX, mouseY-pmouseY);
							} else {
								tool.move(mouseX-pmouseX, mouseY-pmouseY);
							}
						} else {//\u4f55\u3082\u3057\u306a\u3044\u306a\u3089\u56de\u8ee2\u79fb\u52d5
							//4.\u56de\u8ee2\u79fb\u52d5
							if (!tool.moveWriter) {//\u5168\u4f53\u79fb\u52d5
								data.get(tool.nowDataNumber).rotate(radians(pmouseX-mouseX)/10, radians(pmouseY-mouseY)/10, 0);
							} else {//\u500b\u3005
								tool.rotate(radians(pmouseX-mouseX)/10, radians(pmouseY-mouseY)/10, 0);
							}
						}
						break;
				}
		}
	}
}

//\u30ad\u30fc\u30dc\u30fc\u30c9\u306e\u64cd\u4f5c
public void keyPressed(java.awt.event.KeyEvent e) {
	if (tool.getMode()) {
		tool.shortCut(e.getKeyCode());
		super.keyPressed(e);
		int dx=0, dy=0;
		switch(e.getKeyCode()) {//\u79fb\u52d5\u91cf\u3092\u6c42\u3081\u308b
			case LEFT:
				dx=-1;
				break;
			case RIGHT:
				dx=+1;
				break;
			case UP:
				dy=-1;
				break;
			case DOWN:
				dy=+1;
				break;
		}
		switch(e.getKeyCode()) {
			case '0':
				if (!tool.moveWriter)
					data.get(tool.nowDataNumber).matrixReset();
				else
					tool.matrixReset();
				break;
			case LEFT:
			case RIGHT:
			case UP:
			case DOWN://\u3069\u308c\u304b\u306e\u79fb\u52d5\u30ad\u30fc\u304c\u62bc\u3055\u308c\u3066\u3044\u308b\u3068\u304d
				println("\u3044\u3069\u3046");
				if (data.get(tool.nowDataNumber).moveAble()) {
					if (!tool.moveWriter) {
						if (e.isShiftDown()) {
							data.get(tool.nowDataNumber).rotate(dx*PI/100, dy*PI/100, 0);
						} else {
							data.get(tool.nowDataNumber).move(dx*100, dy*100);
							println("\u3046\u3054\u3051\u30fc");
						}
					} else {
						if (e.isShiftDown())
							tool.rotate(dx*PI/100, dy*PI/100, 0);
						else
							tool.move(dx*100, dy*100);
					}
				}
				break;
			case DELETE://\u5168\u6d88\u3057
				data.get(tool.nowDataNumber).clear();
				break;
			case TAB://\u30c4\u30fc\u30eb\u8868\u793a\u3057\u306a\u304a\u3057
				tool.review();
				break;
			case 'S'://\u30c7\u30fc\u30bf\u306e\u63cf\u753b\u30e2\u30fc\u30c9\u3092\u5909\u66f4
				data.get(tool.nowDataNumber).changeDrawMode();
				println("\u63cf\u753b\u3092\u5909\u66f4 "+data.get(tool.nowDataNumber).draw_mode);
				break;
			case 'L'://\u30ed\u30fc\u30c9(debug\u7528)
				if (debugMode&&data.size()==1)
					data.add(new Data(FilePath1));
				break;
			case 'P'://\u30c7\u30fc\u30bf\u3092pcd\u3068\u3057\u3066\u66f8\u304d\u51fa\u3059
				println("make pcd data");
				printPCD();
				//data.get(tool.nowDataNumber).saveJsonData();
				data.get(tool.nowDataNumber).saveJsonArrayData();

				break;

			case'T'://\u30c7\u30fc\u30bf\u306e\u64ae\u5f71
				println("takeShot!");
				take.save();
				break;

			case'A'://\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3
				animation=!animation;
				println("animation\u306e\u5207\u308a\u66ff\u3048 animation:"+animation);
				//println("");
				break;

			default:
				break;
		}
	}
}

public void printPCD() {
	println("printPCD");
	StringList l = new StringList();
	int linenum=0;
	//pcl\u7528\u306e\u30d8\u30c3\u30c0\u3092\u8ffd\u52a0
	l.append("VERSION .7");
	l.append("FIELDS x y z rgb");
	l.append("SIZE 4 4 4 4");
	l.append("TYPE F F F F");
	l.append("COUNT 1 1 1 1");
	/*
       l.append("WIDTH "+str(data_width/2));
   l.append("HEIGHT "+str(data_height/2));
   */
	l.append("WIDTH 1");
	l.append("HEIGHT 1");
	l.append("VIEWPOINT 0 0 0 1 0 0 0");
	l.append("POINTS 0");
	l.append("DATA ascii");

	//realWorldPoint\u306e\u4e2d\u8eab\u3092\u3059\u3079\u3066\u51fa\u529b
	int W=data.get(tool.nowDataNumber).getW();//\u30c7\u30fc\u30bf\u306e\u5e45
	int H=data.get(tool.nowDataNumber).getH();//\u30c7\u30fc\u30bf\u306e\u9ad8\u3055
	for (int y=0; y < H; y+=3) {//3\u305a\u3064\u8aad\u307f\u8fbc\u307f
		for (int x=0; x < W; x+=3) {//3\u305a\u3064\u8aad\u307f\u8fbc\u307f
			int index = x + y * W;//\u30a4\u30f3\u30c7\u30c3\u30af\u30b9\u3092\u8a08\u7b97\u3059\u308b
			PVector realWorldPoint = data.get(tool.nowDataNumber).getVector(index);//realWorldMap_back\u306eindex\u306e\u5024\u3092\u53d6\u5f97\u3059\u308b
			if (realWorldPoint.z > 0) {//\u3082\u3057\u30dd\u30a4\u30f3\u30c8\u306e\uff5a\u306e\u5024\u304c0\u4ee5\u4e0a\u306a\u3089
				linenum++;//linenum\u30921\u5897\u3084\u3059
				l.append(str(realWorldPoint.x)+" "+str(realWorldPoint.y)+" "+str(realWorldPoint.z)+" "+"4.2108e+06");//\u5024\u306ex\u5ea7\u6a19,y\u5ea7\u6a19,z\u5ea7\u6a19,\u8272\u60c5\u5831\u3092\u66f8\u304d\u8fbc\u3080
			}
		}
	}

	for (int i=linenum; linenum!=data_width*data_height/4; linenum++) {
		l.append("");
	}
	l.set(5, "WIDTH "+linenum);//5\u884c\u76ee\u306b\u884c\u6570\u3092\u66f8\u304f
	l.set(8, "POINTS "+linenum);//8\u884c\u76ee\u306b\u30dd\u30a4\u30f3\u30c8\u6570\u306e\u5408\u8a08\u3092\u66f8\u304f

	saveStrings("data/PointCroudData.pcd", l.array());//pcd\u30c7\u30fc\u30bf\u306e\u66f8\u304d\u51fa\u3057
	saveStrings("data/PointCroudData.txt", l.array());//txt\u30c7\u30fc\u30bf\u306e\u66f8\u304d\u51fa\u3057(\u78ba\u8a8d\u7528)
	println("end : printPCD");
	return;
}

public void stop() {
	song.close();
	minim.stop();
	super.stop();
}

//import java.awt.*;

public class RoundButton extends Button {//\u4e38\u30dc\u30bf\u30f3
	public boolean hideButtonLine;
	private PImage img;
	public RoundButton(float x, float y, float w) {//\u30b5\u30a4\u30ba\u3082\u6307\u5b9a
		super(x, y, w, w);
		hideButtonLine=false;
	}
	public RoundButton(PImage g, float x, float y, float w) {//\u30b5\u30a4\u30ba\u3082\u6307\u5b9a
		super(x, y, w, w);
		img=g;
		hideButtonLine=false;
	}

	public boolean pointOver(float x, float y) {//\u70b9\u304c\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u4e0a\u306b\u3042\u308b\u304b
		//x,y\u306f\u30de\u30a6\u30b9\u306exy\u5ea7\u6a19
		float distance = dist(getX(), getY(), x, y);
		return distance<getW();
	}

	//====================//

	public void draw(float x, float y) {
		if (visibility) {
			rectMode(CORNER);
			imageMode(CORNER);
			//      noFill();
			fill(0xffffffff);
			stroke(0xffaaaaaa);
			strokeWeight(2);

			if (selected) 
				fill(0xffaaaaff, 50+(isMouseOver?50:0));
			if (selected)
				stroke(0xff4A4B89);
			else if (isMouseOver)
				stroke(0xff9999AA);
			if (!hideButtonLine||(selected||isMouseOver))
				ellipse(getX(), getY(), getW(), getW());
			image(img, getX()-img.width/2-5, getY()-img.height/2+30, img.width*0.7f, img.height*0.7f);
			strokeWeight(1);
		}
	}
}


public class Im2Button extends Button {
	PImage img1, img2;
	boolean no;
	public Im2Button(PImage g1, PImage g2, float x, float y) {//\u30b5\u30a4\u30ba\u306f\u753b\u50cf\u901a\u308a
		this(g, g2, x, y, g1.width, g1.height);
	}
	public Im2Button(PImage g1, PImage g2, float x, float y, float w, float h) {//\u30b5\u30a4\u30ba\u3082\u6307\u5b9a
		super(x, y, w, h);
		img1=g1;
		img2=g2;
		no=true;
	}

	public void draw(float x, float y) {
		rectMode(CORNER);
		imageMode(CORNER);
		noFill();
		stroke(0xffaaaaaa);
		strokeWeight(2);
		if (selected) 
			fill(0xffaaaaff, 50+(isMouseOver?50:0));
		if (selected||isMouseOver)
			stroke(0xff3333ff);
		rect(getX(), getY(), getW(), getH());
		image(no?img1:img2, getX(), getY(), getW(), getH());
		strokeWeight(1);
	}
}

public class ImButton extends Button {//\u30a4\u30e1\u30fc\u30b8\u4ed8\u304d\u30dc\u30bf\u30f3
	private PImage img;
	public boolean hideButtonLine;
	public ImButton(PImage g, float x, float y) {//\u30b5\u30a4\u30ba\u306f\u753b\u50cf\u901a\u308a
		this(g, x, y, g.width, g.height);
		hideButtonLine=false;
	}
	public ImButton(PImage g, float x, float y, float w, float h) {//\u30b5\u30a4\u30ba\u3082\u6307\u5b9a
		super(x, y, w, h);
		img=g;
		hideButtonLine=false;
	}



	//====================//

	public void draw(float x, float y) {
		if (visibility) {
			rectMode(CORNER);
			imageMode(CORNER);
			noFill();
			stroke(0xffaaaaaa);
			strokeWeight(2);
			if (selected) 
				fill(0xffaaaaff, 50+(isMouseOver?50:0));
			if (selected)
				stroke(0xff4A4B89);
			else if (isMouseOver)
				stroke(0xff9999AA);
			if (!hideButtonLine||(selected||isMouseOver))
				rect(getX(), getY(), getW(), getH());
			image(img, getX(), getY(), getW(), getH());
			strokeWeight(1);
		}
	}
}

public class Button extends Obj {//\u30dc\u30bf\u30f3
	public boolean selected;//\u9078\u629e\u3055\u308c\u3066\u3044\u308b\u304b
	public boolean isMouseOver;//\u30de\u30a6\u30b9\u304c\u4e57\u3063\u3066\u3044\u308b\u304b
	public boolean isPressed;//\u30af\u30ea\u30c3\u30af\u3055\u308c\u305f\u77ac\u9593\u304b\u3069\u3046\u304b
	public boolean isReleased;//\u96e2\u3055\u308c\u305f\u77ac\u9593\u304b\u3069\u3046\u304b
	public boolean visibility;//\u8868\u793a\u3067\u304d\u308b\u304b\u3069\u3046\u304b

	public Button(float x, float y, float w, float h) {//\u30dc\u30bf\u30f3\u306e\u5ea7\u6a19\u3068\u30b5\u30a4\u30ba\u3092\u6307\u5b9a
		super(x, y, w, h);
		selected=false;
		isMouseOver=false;
		isPressed=false;
		visibility=true;
	}

	public void update(float x, float y) {//\u30dc\u30bf\u30f3\u306e\u52d5\u4f5c\u3092\u66f4\u65b0.\u30de\u30a6\u30b9\u306e\u5ea7\u6a19\u3092\u5f15\u6570\u3068\u3057\u3066\u4e0e\u3048\u308b
		if (!visibility) {
			selected=false;
			isMouseOver=false;
			isPressed=false;
			isReleased=false;
			isReleased=false;
			return;
		}

		isMouseOver=pointOver(x, y);//\u30de\u30a6\u30b9\u306e\u5ea7\u6a19\u304c\u30dc\u30bf\u30f3\u4e0a\u306b\u3042\u308b\u304b
		isPressed=pressed();
		isReleased=released();
		if (isPressed)//\u62bc\u3055\u308c\u305f\u6642\u306b\u9078\u629e\u72b6\u614b\u306b\u3059\u308b
			setSelected(true);
	}

	public void setSelected(boolean t) {//\u30dc\u30bf\u30f3\u304c\u9078\u629e\u3055\u308c\u3066\u3044\u308b\u304b\u3055\u308c\u3066\u3044\u306a\u3044\u304b\u3092\u5909\u66f4\u3059\u308b
		selected=t;
	}

	public boolean selected() {
		return selected;
	}

	private boolean pressed() {//\u62bc\u3055\u308c\u305f\u77ac\u9593\u3067\u3042\u308b\u304b\u3069\u3046\u304b
		return isMouseOver&&!pmousePressed&&mousePressed;
	}
	private boolean released() {//\u96e2\u3055\u308c\u305f\u77ac\u9593\u3067\u3042\u308b\u304b\u3069\u3046\u304b
		return pmousePressed&&!mousePressed;
	}
}

public class Obj {//\u5de6\u4e0a\u3092\u57fa\u6e96\u70b9\u3068\u3057\u305f\u30aa\u30d6\u30b8\u30a7\u30af\u30c8
	private float x, y;//\u5ea7\u6a19
	private float cx, cy;//\u4e2d\u592e\u5ea7\u6a19
	private float w, h;//\u30b5\u30a4\u30ba

	public Obj(float x, float y, float w, float h) {//\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u306e\u5ea7\u6a19\u3068\u30b5\u30a4\u30ba\u3092\u6307\u5b9a
		this.x=x;
		this.y=y;
		this.h=h;
		this.w=w;
		cx=x+w/2;
		cy=y+h/2;
	}

	public void update(float x, float y) {//abstract\u306a\u30a4\u30e1\u30fc\u30b8
	}

	public boolean pointOver(float x, float y) {//\u70b9\u304c\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u4e0a\u306b\u3042\u308b\u304b
		return abs(cx-x)<w/2&&abs(cy-y)<h/2;
	}

	public void setPosition(float x, float y) {//\u5ea7\u6a19\u3092\u8a2d\u5b9a\u3059\u308b
		this.x=x;
		this.y=y;
		cx=x+w/2;
		cy=y+h/2;
	}
	public void addPosition(float dx, float dy) {//\u5ea7\u6a19\u3092\u305a\u3089\u3059
		x+=dx;
		y+=dy;
		cx=x+w/2;
		cy=y+h/2;
	}

	//\u5404\u7a2e\u30b2\u30c3\u30bf\u30fc
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	public float getW() {
		return w;
	}
	public float getH() {
		return h;
	}
}

//\u64ae\u5f71\u3057\u305f\u3089\u81ea\u52d5\u4fdd\u5b58
// path/Users/kawasemi/Dropbox/intraction/***.dsd
//




public class Data {//DepthDatadraw\u3092\u4e26\u5217\u51e6\u7406\u306b\u3059\u308c\u3070\u8efd\u304f\u306a\u308b\u304b\uff1f
	private PVector pos;
	private float rotX, rotY, rotZ;//\u56de\u8ee2\u91cf
	private int draw_mode;//\u5199\u771f\u3068\u7dda\u3092\u8868\u793a(0) \u7dda\u3060\u3051\u8868\u793a(1) \u6df1\u5ea6\u3068\u7dda\u3092\u8868\u793a(2) \u8868\u793a\u306a\u3057(3) 

	private PImage img;
	private int [] depthMap;
	private PVector[] realWorldMap, realWorldMap_back;
	private ArrayList<DT> lines, undo;

	int repoint;//\u88dc\u6b63\u3092\u958b\u59cb\u3057\u305f\u5834\u6240(\u6dfb\u5b57)

	public boolean loadAbled=false;//\u30ed\u30fc\u30c9\u306b\u6210\u529f\u3057\u305f\u304b\u3069\u3046\u304b\u3002false\u306e\u3068\u304dArrayList<Data>\u304b\u3089\u524a\u9664\u3059\u308b
	public boolean defaultData=false;//\u7a7a\u306e\u30c7\u30fc\u30bf\u3067\u3042\u308b\u304b\u3069\u3046\u304b\u3002
	public boolean shouldupdate=false;//\u56de\u8ee2\u3001\u79fb\u52d5\u7b49\u3057\u305f\u304b\u3069\u3046\u304b\u3002\u5c04\u5f71\u3059\u308b\u3068\u304d\u306b\u4f7f\u3046
	private float RotateMatrix[]=new float[16];//X\u8ef8\u3067\u306e\u56de\u8ee2\u306e\u305f\u3081\u306e\u884c\u5217

	private PVector[] projectionMap;//projectionMap\u306f\u56de\u8ee2\u5f8c\u3092\u898b\u308b\u305f\u3081\u306b\u4f7f\u3046
	public String dataname="";

	//	private String Savepath = "/Users/kawasemi/Desktop/dsdData/";//mac\u7248/\u9078\u629e\u3057\u305f\u30d5\u30a1\u30a4\u30eb

	//private String Savepath="C:\\Users\\imlab\\Desktop\\dsdData\\kikuchi"+year()+month()+day()+hour()+"_"+minute()+"_"+second()+".dsd";//windows\u7248
	//private String Savepath="C:\\Users\\sumi_000\\Desktop\\dsdData\\oikawa"+year()+month()+day()+hour()+"_"+minute()+"_"+second()+".dsd";//windows\u7248

	private void ready() {
		realWorldMap_back=new PVector[realWorldMap.length];
		projectionMap=new PVector[realWorldMap.length];

		for (int i=0; i<realWorldMap.length; i++) {
			realWorldMap_back[i]=new PVector();
			realWorldMap_back[i].set(realWorldMap[i].x, realWorldMap[i].y, realWorldMap[i].z);

			projectionMap[i]=new PVector();
			projectionMap[i].set(realWorldMap[i].x, realWorldMap[i].y, realWorldMap[i].z);
		}

		undo=new ArrayList<DT>();

		draw_mode=0;
		matrixReset();
	}

	public Data(boolean t) {//\u7a7a\u306e\u30c7\u30fc\u30bf\u3092\u5165\u308c\u308b\u305f\u3081\u306e\u30b3\u30f3\u30b9\u30c8\u30e9\u30af\u30bf
		frame.setTitle("DKBK Now Loading...");
		defaultData=true;

		pos=new PVector();
		lines=new ArrayList<DT>();
		PGraphics g=createGraphics(640, 480);//\u7591\u4f3c\u753b\u50cf\u3092\u4f5c\u308b
		//    g=createGraphics(width, height);//\u30b5\u30a4\u30ba\u304c640*480\u610f\u5916\u3060\u3068\u305a\u308c\u308b
		g.beginDraw();
		g.background(252, 251, 246);

		/*
    g.rect(0, 0, 100, 100);
     g.rect(g.width, 0, -100, 100);
     g.rect(g.width, g.height, -100, -100);
     g.rect(0, g.height, 100, -100);
     */
		g.endDraw();
		img=g;
		depthMap=new int[img.width*img.height];
		realWorldMap=new PVector[img.width*img.height];
		for (int i=0; i<realWorldMap.length; i++)//\u6df1\u5ea6\u60c5\u5831\u30ca\u30b7\u3067depthData\u3092\u4f5c\u6210
			realWorldMap[i]=new PVector();

		loadAbled=true;

		ready();
	}

	public Data() {//\u9078\u629e\u30c0\u30a4\u30a2\u30ed\u30b0\u3092\u958b\u3044\u3066\u8aad\u307f\u8fbc\u307f
		frame.setTitle("DKBK Now Loading...");
		FileDialog fd=new FileDialog(frame, "\u30d5\u30a1\u30a4\u30eb\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044", FileDialog.LOAD);
		//    fd.setFilenameFilter(getFileExtensionFilter(".dsd"));
		fd.setVisible(true);
		if (fd.getFile()==null||fd.getFile().length()==0)
			return;

		String path=fd.getDirectory()+fd.getFile();
		pos=new PVector();
		lines=new ArrayList<DT>();
		if (!load(path)) return;
		loadAbled=true;

		ready();
	}

	//takeshot\u306e\u30c7\u30fc\u30bf\u3092\u305d\u306e\u307e\u307e\u8aad\u307f\u8fbc\u3080
	public Data(PImage timg, int tdepthMap[], PVector[] trealWorldMap) {//takeshot\u306e\u30c7\u30fc\u30bf\u3092\u305d\u306e\u307e\u307e\u8aad\u307f\u8fbc\u3080
		println("takeshot\u306e\u30c7\u30fc\u30bf\u3092\u305d\u306e\u307e\u307e\u8aad\u307f\u8fbc\u3080");
		//frame.setTitle("DKBK Now Loading...");
		pos=new PVector();
		lines=new ArrayList<DT>();

		loadAbled=true;

		//\u3046\u3051\u3068\u3063\u305f\u8981\u7d20\u3092\u4ee3\u5165\u3057\u3066\u521d\u671f\u5316
		img=timg;
		depthMap=new int[img.width*img.height];
		realWorldMap=new PVector[img.width*img.height];
		realWorldMap_back=new PVector[img.width*img.height];
		for (int i=0; i<tdepthMap.length; i++) {
			//println("depthmap\u3092\u518d\u69cb\u7bc9");
			depthMap[i]=tdepthMap[i];
		}

		for (int i=0; i<trealWorldMap.length; i++) {
			realWorldMap[i]=trealWorldMap[i];
		}


		for (int i=0; i<realWorldMap.length; i++) {
			realWorldMap_back[i]=new PVector();
			realWorldMap_back[i].set(realWorldMap[i].x, realWorldMap[i].y, realWorldMap[i].z);
		}

		ready();
	}


	public Data(String path) {//\u30d1\u30b9\u3092\u76f4\u63a5\u6307\u5b9a\u3057\u3066\u8aad\u307f\u8fbc\u307f
		frame.setTitle("DKBK Now Loading...");
		pos=new PVector();
		lines=new ArrayList<DT>();
		if (!load(path)) return;
		loadAbled=true;
		ready();
	}

	public int getW() {
		return img.width;
	}
	public int getH() {
		return img.height;
	}
	public PVector getVector(int idx) {
		return realWorldMap_back[idx];
	}

	public void draw() {
		int penColor=tool.getPenColor();
		int penW=tool.getPenWeight();
		int penT=tool.getPenTool();

		if (mousePressed) {
			switch(penT) {
				case 1://\u30b9\u30d7\u30ec\u30fc
					break;
				case 3://\u6df1\u5ea6\u30b9\u30dd\u30a4\u30c8
					float sum=0;
					int x=(int)map(mouseX, 0, width, 0, img.width);//\u30de\u30a6\u30b9\u306ex\u5ea7\u6a19\u3092\u30a4\u30e1\u30fc\u30b8\u753b\u50cf\u4e0a\u306e\u4f4d\u7f6e\u306b\u5909\u63db
					int y=(int)map(mouseY, 0, height, 0, img.height);//\u30de\u30a6\u30b9\u306ey\u5ea7\u6a19\u3092\u30a4\u30e1\u30fc\u30b8\u753b\u50cf\u4e0a\u306e\u4f4d\u7f6e\u306b\u5909\u63db
					int n=0;//\u6df1\u5ea6\u304c\u5b58\u5728\u3057\u305f\u70b9\u306e\u6570
					for (int iy=-10; iy<=10; iy++)//iy<10\u307e\u3067(\u307e\u308f\u308a\u306e\u5024\u3082\u3068\u308b\u305f\u3081)
						for (int ix=-10; ix<=10; ix++) {//ix<10\u307e\u3067(\u307e\u308f\u308a\u306e\u5024\u3082\u3068\u308b\u305f\u3081)
							if (0<=x+ix&&x+ix<img.width&&0<=y+iy&&iy+y<img.height) {//\u753b\u50cf\u7bc4\u56f2\u5185\u306e\u3068\u304d\u3060\u3051\u51e6\u7406\u3092\u5b9f\u884c
								//              if (depthMap[(y+iy)*img.width+(x+ix)]!=0) {
								if (realWorldMap[(y+iy)*img.width+(x+ix)].z!=0) {//\u30c7\u30fc\u30bf\u304c\u3042\u308c\u3070
									//                sum+=depthMap[(y+iy)*img.width+(x+ix)];
									if (mouseButton==LEFT)
										sum+=realWorldMap[(y+iy)*img.width+(x+ix)].z;//\u3082\u3057\u30af\u30ea\u30c3\u30af\u3057\u305f\u3089sum\u5024\u3092\u5909\u66f4
									else
										sum+=myScreenZ(realWorldMap[(y+iy)*img.width+(x+ix)].x, realWorldMap[(y+iy)*img.width+(x+ix)].y, realWorldMap[(y+iy)*img.width+(x+ix)].z);
									n++;
								}
							}
						}
					if (n>0) {
						tool.setSpoit(sum/n);//\u5e73\u5747\u5024\u3092\u7b97\u51fa\u3057\u3066\u51fa\u529b
					}

					break;
			}
		}
	}


	public void redo() {//\u5143\u306b\u623b\u3059
		if (lines.size()==0)return;
		DT d=lines.get(lines.size()-1);
		if (d.getClass().toString().contains("Cut")) {//\u6700\u5f8c\u306e\u304c\u30ab\u30c3\u30c8\u30c7\u30fc\u30bf
			int n=((Cut)d).getN();
			lines.get(n).addAll(lines.remove(n+1));//\u524d\u306e\u3068\u5f8c\u308d\u306e\u3092\u7d50\u5408
		}
		undo.add(0, lines.remove(lines.size()-1));
	}
	public void undo() {//\u3084\u308a\u76f4\u3057
		if (undo.size()>0)
			lines.add(undo.remove(0));
	}
	public void clear() {//\u5168\u6d88\u53bb
		lines.clear();
	}
	public void undoclear() {
		undo.clear();
	}

	private void updateMap() {
		if (shouldupdate)
			return;

		if (!shouldupdate)return;
		shouldupdate=false;
		pushMatrix();
		setMatrix();
		for (int i=0; i<realWorldMap.length; i++)
			realWorldMap[i].set(0, 0, 0);
		for (PVector p : realWorldMap_back) {
			if (p.z==0)continue;
			int x=round(map(screenX(p.x, p.y, p.z), 0, width, 0, img.width));
			int y=round(map(screenY(p.x, p.y, p.z), 0, height, 0, img.height));
			if (0<=x&&x<img.width&&0<=y&&y<img.height) {
				int idx=x+y*img.width;
				realWorldMap[idx].set(p.x, p.y, p.z);
			}
		}
		popMatrix();
	}
	public void move(float x, float y) {
		shouldupdate=true;
		switch(tool.nowAxisNumber) {
			case 0:
				pos.x+=x*cos(rotY)+y*sin(rotY);
				pos.z+=x*sin(rotY)-y*cos(rotY);
				break;
			case 1:
				pos.x+=x*cos(rotY);
				pos.z+=x*sin(rotY);
				pos.y+=-y;
				break;
		}
	}
	public void rotate(float dy, float dx, float dz) {
		shouldupdate=true;
		rotX+=dx;
		rotY+=dy;
		rotZ+=dz;
	}
	public void matrixReset() {//\u79fb\u52d5\u91cf\u3092\u30ea\u30bb\u30c3\u30c8\u3059\u308b
		shouldupdate=true;
		pos.set(0, 0, 0);
		rotX=PI;
		rotZ=0;
		rotY=0;
	}
	public boolean isDefaultPosition() {//\u79fb\u52d5\u3057\u3066\u306a\u3044\u304b\u3069\u3046\u304b\u3002sin\u3092\u4f7f\u3063\u3066\u3044\u308b\u306e\u306f\u8a08\u7b97\u8aa4\u5dee\u3092\u8a31\u5bb9\u3059\u308b\u305f\u3081
		return pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01f&&abs(sin(rotY-0))<0.01f;
	}

	public void setMatrix() {//\u79fb\u52d5\u91cf\u3092\u53cd\u6620
		tool.setMatrix();
		translate(width/2, height/2);
		rotateX(rotX);
		rotateY(rotY);
		rotateY(rotZ);
		scale(0.575f*width/img.width);
		translate(0, 0, -1000);
		translate(pos.x, pos.y, pos.z);
	}


	public void cameraupdate(PImage timg, int tdepthMap[], PVector[] trealWorldMap) {
		//frame.setTitle("DKBK Now Loading...");
		pos=new PVector();
		//lines\u306e\u521d\u671f\u5316\u306f\u3057\u306a\u3044
		//lines=new ArrayList<DT>();
		//\u3046\u3051\u3068\u3063\u305f\u8981\u7d20\u3092\u4ee3\u5165\u3057\u3066\u521d\u671f\u5316
		img=timg;
		depthMap=new int[img.width*img.height];
		realWorldMap=new PVector[img.width*img.height];
		realWorldMap_back=new PVector[img.width*img.height];
		for (int i=0; i<tdepthMap.length; i++) {
			//println("depthmap\u3092\u518d\u69cb\u7bc9");
			depthMap[i]=tdepthMap[i];
		}

		for (int i=0; i<trealWorldMap.length; i++) {
			realWorldMap[i]=trealWorldMap[i];
		}

		for (int i=0; i<realWorldMap.length; i++) {
			realWorldMap_back[i]=new PVector();
			realWorldMap_back[i].set(realWorldMap[i].x, realWorldMap[i].y, realWorldMap[i].z);
		}
	}

	public void cameraChangeUpdate(PImage timg, int tdepthMap[], PVector[] trealWorldMap) {
		//\u73fe\u5728\u306e\u5024\u3092\u65b0\u3057\u3044\u30ab\u30e1\u30e9\u306e\u5024\u3067\u63cf\u304d\u63db\u3048\u308b

		//frame.setTitle("DKBK Now Loading...");
		pos=new PVector();
		//lines\u306e\u521d\u671f\u5316\u306f\u3057\u306a\u3044
		//lines=new ArrayList<DT>();
		//\u3046\u3051\u3068\u3063\u305f\u8981\u7d20\u3092\u4ee3\u5165\u3057\u3066\u521d\u671f\u5316
		img=timg;
		depthMap=new int[img.width*img.height];
		realWorldMap=new PVector[img.width*img.height];
		realWorldMap_back=new PVector[img.width*img.height];
		for (int i=0; i<tdepthMap.length; i++) {
			//println("depthmap\u3092\u518d\u69cb\u7bc9");
			depthMap[i]=tdepthMap[i];
		}

		for (int i=0; i<trealWorldMap.length; i++) {
			realWorldMap[i]=trealWorldMap[i];
		}


		for (int i=0; i<realWorldMap.length; i++) {
			realWorldMap_back[i]=new PVector();
			realWorldMap_back[i].set(realWorldMap[i].x, realWorldMap[i].y, realWorldMap[i].z);
		}
	}
	
	public void setCanvasMatrix(PGraphics cv) {//\u79fb\u52d5\u91cf\u3092\u53cd\u6620
//		tool.setMatrix();
		cv.translate(cv.width/2, cv.height/2);
		cv.rotateX(rotX);
		cv.rotateY(rotY);
		cv.rotateY(rotZ);
		cv.scale(0.575f*cv.width/img.width);
		cv.translate(0, 0, -1000);
		cv.translate(pos.x, pos.y, pos.z);
	}

	public void updateDKBKCanvas(PGraphics cv, SimpleOpenNI context) {
		pushMatrix();
		//\u63cf\u753b\u30e2\u30fc\u30c9\u306b\u3088\u3063\u3066\u8868\u793a\u5185\u5bb9\u3092\u5909\u3048\u308b
		//	0 \u5199\u771f\u306e\u8868\u793a
		//	1 
		//	2 \u6df1\u5ea6\u30c7\u30fc\u30bf\u306e\u8868\u793a
		//	3 \u975e\u8868\u793a

		switch(draw_mode){

			case 0:
				cv.hint(DISABLE_DEPTH_TEST);//\u30ec\u30f3\u30c0\u30e9\u30922D\u306b\u5909\u3048\u308b
				//\u753b\u50cf\u3092\u63cf\u753b-\u305f\u3060\u3057\u3001\u3055\u3063\u304d\u307e\u3067\u753b\u9762\u306b\u8868\u793a\u3055\u308c\u3066\u3044\u305f\u30ab\u30e1\u30e9\u306e\u5199\u771f\u306b\u5909\u66f4\u3055\u308c\u3066\u3044\u308b
				cv.tint(255, 120);//\u534a\u900f\u660e\u306b\u3059\u308b
				cv.image(img, 0, 0, cv.width, cv.height);//\u753b\u50cf\u30c7\u30fc\u30bf\u306e\u8868\u793a
				cv.tint(255, 255);//\u900f\u660e\u5ea6\u3092\u5143\u306b\u623b\u3059
				cv.hint(ENABLE_DEPTH_TEST);//\u7d42\u4e86
				break;

			case 2:
				setCanvasMatrix(cv);
				cv.strokeWeight(4);
				for (int y=0; y < img.height; y+=K) {
					for (int x=0; x < img.width; x+=K) {
						int index = x + y * img.width;
						PVector p=realWorldMap_back[index];
						if (p.z > 0) { 
							stroke(img.pixels[index]);
							cv.point(p.x, p.y, p.z);// make realworld z negative, in the 3d drawing coordsystem +z points in the direction of the eye
						}
					}
				}
				cv.strokeWeight(1);
				break;
		}
		popMatrix();
	}
	public void update() {
		pushMatrix();
		if (draw_mode==0) {
			hint(DISABLE_DEPTH_TEST);//\u4e8c\u6b21\u5143\u63cf\u753b\u30e2\u30fc\u30c9
			//\u753b\u50cf\u3092\u63cf\u753b-\u305f\u3060\u3057\u3001\u3055\u3063\u304d\u307e\u3067\u753b\u9762\u306b\u8868\u793a\u3055\u308c\u3066\u3044\u305f\u30ab\u30e1\u30e9\u306e\u5199\u771f\u306b\u5909\u66f4\u3055\u308c\u3066\u3044\u308b
			//\u534a\u900f\u660e\u306b\u3059\u308b
			tint(255, 120);
			image(img, 0, 0, width, height);
			//\u900f\u660e\u5ea6\u3092\u5143\u306b\u623b\u3059
			tint(255, 255);
			hint(ENABLE_DEPTH_TEST);//\u7d42\u4e86
		}

		setMatrix();
		//\u4ed6\u306e\u30c7\u30fc\u30bf\u3082\u66f4\u65b0\u3059\u308b

		if (draw_mode==2) {
			//\u6df1\u5ea6\u30c7\u30fc\u30bf\u304c\u3042\u308b\u5834\u6240\u306b\u30d4\u30af\u30bb\u30eb\u3092\u63cf\u753b
			/*
      loadPixels();
       img.loadPixels();
       int isthere[]=new int[pixels.length];
       for (int iy=0; iy<img.height; iy++)
       for (int ix=0; ix<img.width; ix++) {
       PVector p=realWorldMap_back[ix+iy*img.width];
       if (p.z==0)continue;
       int x=int(screenX(p.x, p.y, p.z));
       int y=int(screenY(p.x, p.y, p.z));
       int z=int(screenZ(p.x, p.y, p.z));
       if (!(0<=x&&x<width&&0<=y&&y<height))continue;
       int idx=x+y*width;
       if (isthere[idx]==0||isthere[idx]>z) {
       isthere[idx]=z;
       pixels[idx]=img.pixels[ix+iy*img.width];
       }
       }


       img.updatePixels();
       updatePixels();

       */
		}
		if (draw_mode!=3)
			drawLine();
		popMatrix();

		//todo
		pushMatrix();
		setMatrix();


		if (draw_mode==2) {
			drawDepthData();
		}
		popMatrix();
	}

	public void addLine() {//mousePressed\u6642\u306b\u547c\u3076
		switch(tool.nowToolNumber) {
			case 0://\u30c7\u30fc\u30bf\u3068\u3057\u3066\u7dda\u3092\u8ffd\u52a0
				if (tool.getPenColorNum()>1) {//color c\u304c\u30b9\u30dd\u30a4\u30c8\u3058\u3083\u306a\u3044\u306a\u3089
					lines.add(new Line(tool.getPenColor(), tool.getPenWeight()));//\u8272\u3092icon\u306e\u8272\u306b\u5909\u66f4
				} else if (tool.getPenColorNum()==0) {//\u5199\u771f\u30b9\u30dd\u30a4\u30c8
					tool.penColor[0]=img.get(
						PApplet.parseInt(map(mouseX, 0, width, 0, img.width)), 
						PApplet.parseInt(map(mouseY, 0, height, 0, img.height))
					);
					lines.add(new Line(tool.getPenColor(), tool.getPenWeight()));
				} else if (tool.getPenColorNum()==1) {//\u5199\u771f\u30b9\u30dd\u30a4\u30c82.\u30e9\u30f3\u30c0\u30e0
					tool.penColor[1]=img.get(
						PApplet.parseInt(random(0, img.width)), 
						PApplet.parseInt(random(0, img.height))
					);
					lines.add(new Line(tool.getPenColor(), tool.getPenWeight()));
				}
				undoclear();
				break;
			case 1://\u30c7\u30fc\u30bf\u3068\u3057\u3066\u30b9\u30d7\u30ec\u30fc\u3092\u8ffd\u52a0->\u7dda\u3092\u8ffd\u52a0
				//lines.add(new Spray(tool.getPenColor(), tool.getPenWeight()));
				lines.add(new Line(tool.getPenColor(), tool.getPenWeight()));
				undoclear();
				break;
		}
	}

	public boolean moveAble() {
		return draw_mode!=0;
	}
	public void changeDrawMode() {
		draw_mode=(draw_mode+1)%4;
	}

	public void d() {
		drawLine();
	}

	private void drawLine() {
		noFill();
		for (DT line : lines) {
			//if (!line.ableDraw())continue;
			stroke(line.c);
			strokeWeight(line.w);
			if (line.beginShape()==-1)
				beginShape();
			else
				beginShape(line.beginShape());
			for (PVector p : line) {
				vertex(p.x, p.y, p.z);
				vertex(p.x, p.y, p.z);//vertex\u4e00\u56de\u3060\u3068\u306a\u305c\u304b\u7dda\u3092size()==2\u306e\u6642\u306a\u305c\u304b\u7dda\u3092\u66f8\u3044\u3066\u304f\u308c\u306a\u3044
			}
			endShape();
			//drawArea();
			strokeWeight(1);
		}
	}

	private void drawArea() {//\u9078\u629e\u4e2d\u306e\u30c7\u30fc\u30bf\u306e\u5468\u308a\u306b\u7dda\u3092\u8868\u793a\u3059\u308b

		noFill();
		stroke(100, 100, 255);
		strokeWeight(4);

		//\u624b\u524d
		beginShape();
		vertex(-width/3, -height/3, 400);
		vertex(width/3, -height/3, 400);
		vertex(width/3, height/3, 400);
		vertex(-width/3, height/3, 400);
		endShape(CLOSE);

		stroke(200, 200, 255);

		//\u304a\u304f
		beginShape();
		vertex(-width*2.5f, -height*2.5f, 6000);
		vertex(width*2.5f, -height*2.5f, 6000);
		vertex(width*2.5f, height*2.5f, 6000);
		vertex(-width*2.5f, height*2.5f, 6000);
		endShape(CLOSE);

		//\u305d\u306e\u307b\u304b
		/*
    beginShape(LINES);
     vertex(-width/3, -height/3, 400);
     vertex(-width*2.5, -height*2.5, 6000);

     vertex(width/3, -height/3, 400);
     vertex(width*2.5, -height*2.5, 6000);

     vertex(width/3, height/3, 400);
     vertex(width*2.5, height*2.5, 6000);

     vertex(-width/3, height/3, 400);
     vertex(-width*2.5, height*2.5, 6000);
     endShape();
     */

		//\u5730\u9762\u3082\u8868\u793a\u3059\u308b
		/*
    beginShape(LINES);
     stroke(255, 100, 255);
     int c_count=0;
     while (c_count<=10) {


     vertex(-width/3+(width*2/3/10)*c_count, -height/3, 400);
     vertex(-width/3+(width*2/3/10)*c_count, -height/3, 6000);

     c_count++;
     }
     endShape();
     */
	}
	private void drawDepthData() {//\u6df1\u5ea6\u30c7\u30fc\u30bf\u3092\u63cf\u753b\u3059\u308b

		if (tool.nowToolNumber==4) {
			noFill();
			stroke(255);
			box(100, 500, 100);
		}
		int K=4;
		strokeWeight(K);
		for (int y=0; y < img.height; y+=K) {
			for (int x=0; x < img.width; x+=K) {
				int index = x + y * img.width;
				PVector p=realWorldMap_back[index];
				if (p.z > 0) { 
					stroke(img.pixels[index]);

					point(p.x, p.y, p.z);  // make realworld z negative, in the 3d drawing coordsystem +z points in the direction of the eye
				}
			}
		}
		strokeWeight(1);
	}
	//todo mouseX,mouseY\u3092\u53d7\u3051\u53d6\u3063\u3066\u3001\u30ad\u30e3\u30f3\u30d0\u30b9\u4f4d\u7f6ePVector x,y,z \u3092\u8fd4\u3059
	public PVector PCanvas(int x, int y) {

		try {//\u305f\u307e\u306bArrayIndexOutOfBoundsException\u3067\u308b\u306e\u3067\u305d\u306e\u4f8b\u5916\u3092\u306f\u3058\u3044\u3066\u304a\u304f\u3002
			if (tool.pointOver(x, y)) return new PVector(0, 0, 0);//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u306a\u3044\u306a\u3089\u7d9a\u3051\u308b
			boolean dp=isDefaultPosition();
			x=(int)map(x, 0, width, 0, img.width);//\u30de\u30a6\u30b9\u5ea7\u6a19\u3092\u753b\u50cf\u4e0a\u306e\u4f4d\u7f6e\u306b\u5909\u63db\u3059\u308b
			y=(int)map(y, 0, height, 0, img.height);
			if (x<0||y<0||x>width||y>height)return  new PVector(0, 0, 0);//\u753b\u9762\u5916\u306b\u66f8\u3044\u3066\u3044\u305f\u3089\u4f55\u3082\u3057\u306a\u3044
			int idx=x+y*img.width;//\u30de\u30a6\u30b9\u4f4d\u7f6e\u3092\u8a08\u7b97\u3059\u308b
			if (idx<0||idx>realWorldMap.length)return new PVector(0, 0, 0);//\u914d\u5217\u306e\u7bc4\u56f2\u5916\u3060\u3063\u305f\u3089\u4f55\u3082\u3057\u306a\u3044
			PVector p=new PVector();//\u8ffd\u52a0\u3059\u308b\u30d9\u30af\u30c8\u30eb
			p.set(realWorldMap_back[idx].x, realWorldMap_back[idx].y, realWorldMap_back[idx].z);

			ArrayList<PVector>line=lines.get(lines.size()-1);//\u4e00\u756a\u6700\u5f8c\u306e\u7dda
			if (p.z==0) {
				//if (dp)return;
				//todo \u56de\u8ee2\u64cd\u4f5c\u3092\u3057\u3066\u3044\u308b\u6642\u3082\u3046\u307e\u304f\u884c\u3048\u308b\u3088\u3046\u306b

				if (!(pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01f&&abs(sin(rotY-PI))<0.01f)) {//\u3082\u3057\u79fb\u52d5\u3055\u308c\u3066\u3044\u305f\u3089\u3001\u4f4d\u7f6e\u3092\u8a08\u7b97\u3057\u306a\u304a\u3057\u3066\u5165\u308c\u3068\u304f
				} else {
					p=calcRealPoint(LENGTH*5, x, y);
				}
				//println("p.z==0\u3067\u3057\u305f");
			}
			if (tool.getSpoit()!=0) {//\u6df1\u5ea6\u304c\u30b9\u30dd\u30a4\u30c8\u3057\u3066\u3042\u308b\u306a\u3089
				p=calcRealPoint(tool.getSpoit(), x, y);
			}

			if (line.size()>0&&tool.nowToolNumber==0) {//\u7dda\u3092\u63cf\u3044\u3066\u3044\u305f\u3089,\u304b\u3064\u88dc\u6b63\u30da\u30f3\u306a\u3089
				PVector pp=line.get(line.size()-1);
				float ax=pp.x+pos.x;
				float ay=pp.y+pos.y;
				float az=pp.z+pos.z;
				if (new PVector(ax, ay, az).dist(p)>tool.getBorder()) {//\u8ddd\u96e2\u304c\u5927\u304d\u3059\u304e\u308b\u3088\u3046\u306a\u3089\u524d\u306e\u70b9\u306e\u5ea7\u6a19\u306e\u3092\u5229\u7528(\u88dc\u6b63\u3059\u308b)
					p=calcRealPoint(az, x, y);
				}
			}

			if (!(pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01f&&abs(sin(rotY-PI))<0.01f)) {//\u3082\u3057\u79fb\u52d5\u3055\u308c\u3066\u3044\u305f\u3089\u3001\u4f4d\u7f6e\u3092\u8a08\u7b97\u3057\u306a\u304a\u3057\u3066\u5165\u308c\u3068\u304f
				p=reCalcPoint(p);//\u518d\u8a08\u7b97\u3059\u308b\u3068\u72c2\u3046
			}
			if (tool.getPenColorNum()>=4) {//color c\u304c\u30b9\u30dd\u30a4\u30c8\u3058\u3083\u306a\u3044\u306a\u3089
				if (tool.getPenWeight()<5) {//\u7d30\u3044\u7dda\u306a\u3089
					//\u7d30\u3044\u7dda\u306f\u624b\u524d\u306b\u305a\u3089\u3059
					p.z=p.z-5;
				} else {
					println("\u592a\u3044\u7dda");
				}
			}
			return p;
		}
		catch(Exception e) {
			println(frameCount, x, y);
			e.printStackTrace();
		}

		return new PVector(0, 0, 0);//\u30c0\u30df\u30fc
	}


	private void addPoint(int x, int y) {//\u30de\u30a6\u30b9\u306e\u5ea7\u6a19\u304c\u5165\u308b
		/*
    if (!(pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01&&abs(sin(rotY-PI))<0.01)) {
     //\u4eca\u306f\u8996\u70b9\u304c\u521d\u671f\u72b6\u614b\u3058\u3083\u306a\u3044\u6642\u306b\u306f\u304b\u3051\u306a\u3044\u3088\u3046\u306b\u3057\u3068\u304f\u3002
     println("Not Default Matrix.");
     return;
     }
     */
		//println("   start addPoint");
		try {//\u305f\u307e\u306bArrayIndexOutOfBoundsException\u3067\u308b\u306e\u3067\u305d\u306e\u4f8b\u5916\u3092\u306f\u3058\u3044\u3066\u304a\u304f\u3002
			if (tool.pointOver(x, y)) return;//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u306a\u3044\u306a\u3089\u7d9a\u3051\u308b
			boolean dp=isDefaultPosition();
			x=(int)map(x, 0, width, 0, img.width);//\u30de\u30a6\u30b9\u5ea7\u6a19\u3092\u753b\u50cf\u4e0a\u306e\u4f4d\u7f6e\u306b\u5909\u63db\u3059\u308b
			y=(int)map(y, 0, height, 0, img.height);
			if (x<0||y<0||x>width||y>height)return;//\u753b\u9762\u5916\u306b\u66f8\u3044\u3066\u3044\u305f\u3089\u4f55\u3082\u3057\u306a\u3044
			int idx=x+y*img.width;//\u30de\u30a6\u30b9\u4f4d\u7f6e\u3092\u8a08\u7b97\u3059\u308b
			if (idx<0||idx>realWorldMap.length)return;//\u914d\u5217\u306e\u7bc4\u56f2\u5916\u3060\u3063\u305f\u3089\u4f55\u3082\u3057\u306a\u3044
			PVector p=new PVector();//\u8ffd\u52a0\u3059\u308b\u30d9\u30af\u30c8\u30eb
			p.set(realWorldMap_back[idx].x, realWorldMap_back[idx].y, realWorldMap_back[idx].z);

			ArrayList<PVector>line=lines.get(lines.size()-1);//\u4e00\u756a\u6700\u5f8c\u306e\u7dda
			if (p.z==0) {
				//if (dp)return;
				//todo \u56de\u8ee2\u64cd\u4f5c\u3092\u3057\u3066\u3044\u308b\u6642\u3082\u3046\u307e\u304f\u884c\u3048\u308b\u3088\u3046\u306b

				if (!(pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01f&&abs(sin(rotY-PI))<0.01f)) {//\u3082\u3057\u79fb\u52d5\u3055\u308c\u3066\u3044\u305f\u3089\u3001\u4f4d\u7f6e\u3092\u8a08\u7b97\u3057\u306a\u304a\u3057\u3066\u5165\u308c\u3068\u304f
				} else {
					p=calcRealPoint(LENGTH*5, x, y);
				}
				//println("p.z==0\u3067\u3057\u305f");
			}
			if (tool.getSpoit()!=0) {//\u6df1\u5ea6\u304c\u30b9\u30dd\u30a4\u30c8\u3057\u3066\u3042\u308b\u306a\u3089
				p=calcRealPoint(tool.getSpoit(), x, y);
			} else {
			}

			//\u3066\u3059\u3068\u6210\u529f
			//println("\u72c2\u3063\u3066\u3044\u308b\u304btest:x "+p.x+" y "+p.y+" z "+p.z);//\u3053\u306e\u6642\u70b9\u3067\u306f\u72c2\u3063\u3066\u306a\u3044

			/****************** \u30e2\u30c7\u30eb\u5ea7\u6a19-\u30b9\u30af\u30ea\u30fc\u30f3\u5ea7\u6a19 *****************

       ****************************************************************/
			//2.\u4f5c\u6210\u3057\u305fprojectionMap\u304b\u3089\u30de\u30a6\u30b9\u306ex,y\u306b\u5bfe\u5fdc\u3059\u308b\u70b9pv\u3092\u5f97\u308b

			//\u56de\u8ee2\u3057\u3066\u3044\u3066\u304b\u3064\u30b9\u30dd\u30a4\u30c8\u3057\u3066\u3044\u306a\u3044\u3068\u304d
			/*
      if (!(pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01&&abs(sin(rotY-PI))<0.01)) {//\u56de\u8ee2\u3057\u3066\u3044\u308b
       PVector pv = new PVector(projectionMap[idx].x, projectionMap[idx].y, projectionMap[idx].z);
       if (tool.getSpoit()==0) {//\u30b9\u30dd\u30a4\u30c8\u3057\u3066\u306a\u3044\u6642
       //3. 2\u3067\u53d6\u5f97\u3067\u304d\u305fpv(x,y,z)\u3092unProjectScreen\u306b\u5165\u308c\u3066\u3001\u30e2\u30c7\u30eb\u5185\u5ea7\u6a19\u3092\u5f97\u308b
       pv.set(unprojectScreen(pv));
       } else {
       pv.z=tool.getSpoit();//z\u306e\u5024\u3060\u3051\u30b9\u30dd\u30a4\u30c8\u306e\u5024\u306b\u7f6e\u304d\u63db\u3048\u308b
       }
       p.set(pv);

       }
       */
			//println("\u88dc\u6b63\u524d "+p.x+" "+p.y+" "+p.z);


			//if ((pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01&&abs(sin(rotY-PI))<0.01)) {//\u56de\u8ee2\u3057\u3066\u3044\u306a\u3044\u306a\u3089
			if (line.size()>0&&tool.nowToolNumber==0) {//\u7dda\u3092\u63cf\u3044\u3066\u3044\u305f\u3089,\u304b\u3064\u88dc\u6b63\u30da\u30f3\u306a\u3089
				PVector pp=line.get(line.size()-1);
				float ax=pp.x+pos.x;
				float ay=pp.y+pos.y;
				float az=pp.z+pos.z;

				if (new PVector(ax, ay, az).dist(p)>tool.getBorder()) {//\u8ddd\u96e2\u304c\u5927\u304d\u3059\u304e\u308b\u3088\u3046\u306a\u3089\u524d\u306e\u70b9\u306e\u5ea7\u6a19\u306e\u3092\u5229\u7528(\u88dc\u6b63\u3059\u308b)
					p=calcRealPoint(az, x, y);
					//\u88dc\u6b63\u524d\u3068\u88dc\u6b63\u5f8c\u306e\u5dee\u3000pp-p
					//PVector dpv=PVector.sub(pp, p);//\u30c0\u30d6\u30eb\u88dc\u6b63\u7528
					//println("\u88dc\u6b63\u524d\u3068\u88dc\u6b63\u5f8c\u306e\u5dee"+dpv);

					//println("\u8ffd\u52a0\u70b9 "+p.x+" "+p.y+" "+p.z);
				}
			}
			//      if (line.size()>0&&tool.nowToolNumber==1) {//\u7dda\u3092\u63cf\u3044\u3066\u3044\u305f\u3089,\u304b\u3064\u88dc\u6b63\u30da\u30f3B\u306a\u3089
			//        PVector pp=line.get(line.size()-1);
			//        if (pp.dist(p)>tool.getBorder()) {//\u8ddd\u96e2\u304c\u5927\u304d\u3059\u304e\u308b\u3088\u3046\u306a\u3089\u524d\u306e\u70b9\u306e\u5ea7\u6a19\u306e\u3092\u5229\u7528(\u88dc\u6b63\u3059\u308b)
			//          p=calcRealPoint(pp.z, x, y);
			//        }
			//      }
			//}

			if (!(pos.x==0&&pos.y==0&&pos.z==0&&abs(sin(rotX-PI))<0.01f&&abs(sin(rotY-PI))<0.01f)) {//\u3082\u3057\u79fb\u52d5\u3055\u308c\u3066\u3044\u305f\u3089\u3001\u4f4d\u7f6e\u3092\u8a08\u7b97\u3057\u306a\u304a\u3057\u3066\u5165\u308c\u3068\u304f
				p=reCalcPoint(p);//\u518d\u8a08\u7b97\u3059\u308b\u3068\u72c2\u3046
			} else {
				//println("\u88dc\u6b63\u306a\u3057");
			}


			if (tool.getPenColorNum()>=4) {//color c\u304c\u30b9\u30dd\u30a4\u30c8\u3058\u3083\u306a\u3044\u306a\u3089
				if (tool.getPenWeight()<5) {//\u7d30\u3044\u7dda\u306a\u3089
					//\u7d30\u3044\u7dda\u306f\u624b\u524d\u306b\u305a\u3089\u3059
					p.z=p.z-5;
				} else {
					println("\u592a\u3044\u7dda");
				}
			}

			line.add(p);//\u7dda\u306b\u70b9\u3092\u8ffd\u52a0
		}
		catch(Exception e) {
			println(frameCount, x, y);
			e.printStackTrace();
		}
		//println("   end addPoint");
	}

	public void cutLine(int px, int py, int x, int y) {//\u4e8c\u6b21\u5143\u306b\u5c04\u5f71\u3057\u3066\u3001\u305d\u308c\u3068\u30de\u30a6\u30b9\u306e\u8ecc\u8de1\u3068\u306e\u4ea4\u5dee\u5224\u5b9a\u3092\u884c\u3044\u3001\u5207\u65ad\u3059\u308b
		//screenXY\u3092\u6b63\u5e38\u306b\u52d5\u4f5c\u3055\u305b\u308b\u305f\u3081\u3001Matrix\u3092\u63cf\u753b\u6642\u3068\u7d71\u4e00\u3059\u308b
		pushMatrix();
		setMatrix();

		PVector v1=new PVector(x-px, y-py);
		for (int j=0; j<lines.size (); j++) {
			DT l=lines.get(j);
			if (!l.ableCut())continue;//\u5207\u308c\u306a\u3044\u3082\u306e\u306f\u98db\u3070\u3059\u3002
			ArrayList<PVector> p=l;
			for (int i=1; i<p.size (); i++) {
				PVector p1=p.get(i-1), p2=p.get(i);
				p1=new PVector(p1.x, p1.y, p1.z);
				p2=new PVector(p2.x, p2.y, p2.z);
				p1.set(screenX(p1.x, p1.y, p1.z), screenY(p1.x, p1.y, p1.z), 0);
				p2.set(screenX(p2.x, p2.y, p2.z), screenY(p2.x, p2.y, p2.z), 0);
				PVector v2=new PVector(p2.x-p1.x, p2.y-p1.y);
				if (isCross(new PVector(px, py), v1, p1, v2)) {
					Line rl=new Line(l.c, l.w);//p=\u5207\u3089\u308c\u305f\u5de6\u5074,rl=\u5207\u3089\u308c\u305f\u53f3\u5074
					while (p.size ()>i)
						rl.add(p.remove(i));
					lines.add(j+1, rl);//\u5de6\u5074\u306e\u4e00\u500b\u5f8c\u308d\u306b\u53f3\u5074\u3092\u8ffd\u52a0
					lines.add(new Cut(l.c, l.w, j));//\u5207\u65ad\u3057\u305f\u3068\u3044\u3046\u30c7\u30fc\u30bf\u3092\u6b8b\u3059
					break;
				}
			}
		}

		popMatrix();
	}

	private boolean load(String path) {
		try {
			//\u3082\u3057\u8aad\u307f\u8fbc\u307f\u30d5\u30a1\u30a4\u30eb\u304c.dsd.png\u3067\u7d42\u308f\u308b\u3088\u3046\u306a\u3089\u3070.png\u3092\u6d88\u3057\u3066\u8aad\u307f\u8fbc\u307f\u3057\u3066\u307f\u308b
			boolean userImage=false;

			if (path.endsWith(".dsd.png")) {
				println("\u753b\u50cf\u306e\u8aad\u307f\u8fbc\u307f\u3067\u3059");
				path = path.replaceAll(".png", "");
				userImage=true;
			}

			File f=new File(path);

			if (!f.exists()) {
				System.err.println("\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
				System.err.println(f.getAbsolutePath()+"\n\u306f\u5b58\u5728\u3057\u307e\u305b\u3093\u3002");
				return false;
			}

			if (!f.canRead()) {
				System.err.println("\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
				System.err.println("\u8aad\u307f\u8fbc\u3080\u3053\u3068\u306e\u3067\u304d\u306a\u3044\u30d5\u30a1\u30a4\u30eb\u3067\u3059\u3002");
				return false;
			}

			String[] splitpath = splitTokens(path, "/");
			println("dataname2 "+splitpath[splitpath.length-1]);
			dataname=splitpath[splitpath.length-1];     


			ObjectInputStream is=new ObjectInputStream(new FileInputStream(f));

			//\u30d5\u30a1\u30a4\u30eb\u304b\u3089\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u3092\u8aad\u307f\u8fbc\u3080
			int w=(Integer)is.readObject();
			int h=(Integer)is.readObject();
			int c[]=(int[])is.readObject();
			depthMap=(int[])is.readObject();
			realWorldMap=(PVector[])is.readObject();
			if (path.endsWith("dsd")) {
				int n=(Integer)is.readObject();
				for (int i=0; i<n; i++) {
					int m=(Integer)is.readObject();
					int cc=(Integer)is.readObject();
					int ww=(Integer)is.readObject();
					DT line=new DT(cc, ww);
					switch(m) {
						case 0:
							line=new Line(cc, ww);
							break;
						case 1:
							line=new Spray(cc, ww);
							break;
					}
					line.addAll((ArrayList<PVector>)is.readObject());
					lines.add(line);
				}
			}

			img=createImage(w, h, ARGB);//\u753b\u50cf\u3092\u6271\u3046\u305f\u3081\u306e\u30d0\u30c3\u30d5\u30a1\u3092\u4f5c\u308b
			println("\u3064\u304f\u3063\u305f\u304c\u305e\u3046\u3055\u3044\u305a"+w+" "+height);
			//img.pixels=c;//\u30d0\u30c3\u30d5\u30a1\u306e\u8272\u30c7\u30fc\u30bf\u3092\u8aad\u307f\u8fbc\u3093\u3060\u30aa\u30d6\u30b8\u30a7\u3067\u66f8\u304d\u63db\u3048\u308b
			img.pixels=c;//\u30d0\u30c3\u30d5\u30a1\u306e\u8272\u30c7\u30fc\u30bf\u3092\u8aad\u307f\u8fbc\u3093\u3060\u30aa\u30d6\u30b8\u30a7\u3067\u66f8\u304d\u63db\u3048\u308b


			//\u5f97\u3089\u308c\u305f\u60c5\u5831\u304b\u3089\u753b\u50cf\u30c7\u30fc\u30bf\u3092\u4f5c\u6210
			if (userImage) {//\u9078\u629e\u30c7\u30fc\u30bf\u304c\u753b\u50cf\u3060\u3063\u305f\u6642
				//img = loadImage(path+".png");
				PImage testImg = loadImage(path+".png");
				testImg.resize(w, h);
				println("\u753b\u50cf\u30b5\u30a4\u30ba "+testImg.width+" "+testImg.height);
				img.pixels=testImg.pixels;
			} else {
				img.pixels=c;
			}

			is.close();//\u4f7f\u3044\u7d42\u308f\u3063\u305f\u3089\u9589\u3081\u308b

			return true;
		}
		catch(Exception e) {
			System.err.println("\u8aad\u307f\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
			e.printStackTrace();
			return false;
		}
	}
	private void save() {
		frame.setTitle("\u4fdd\u5b58\u4e2d");
		try {
			//FileDialog\u3067\u8aad\u307f\u8fbc\u307f\u305f\u3044\u30d5\u30a1\u30a4\u30eb\u3092\u9078\u629e\u3059\u308b
			FileDialog fd=new FileDialog(frame, "\u30d5\u30a1\u30a4\u30eb\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044", FileDialog.SAVE);
			fd.setFilenameFilter(getFileExtensionFilter(".dsd"));
			if (debugMode)
				fd.setFile("test.dsd");
			else
				fd.setFile("*.dsd");
			fd.setVisible(true);
			String path=fd.getDirectory()+fd.getFile();//\u9078\u629e\u3057\u305f\u30d5\u30a1\u30a4\u30eb

			//\u6c7a\u5b9a\u304c\u62bc\u3055\u308c\u3066\u306a\u304b\u3063\u305f\u308a\u3001\u30d5\u30a1\u30a4\u30eb\u540d\u306e\u9577\u3055\u304c0\u3060\u3063\u305f\u308a\u3057\u305f\u3089\u3001\u51fa\u529b\u3092\u4e2d\u65ad
			if (fd.getFile()==null||fd.getFile().length()==0)
				return;
			if (!path.endsWith("dsd"))//\u62e1\u5f35\u5b50\u3092dsd\u306b\u5f37\u5236
				path+=".dsd";

			ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream(new File(path)));
			println("\u4fdd\u5b58-path"+path);

			//\u30d5\u30a1\u30a4\u30eb\u306b\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u3092\u66f8\u304d\u8fbc\u3080
			os.writeObject(img.width);
			os.writeObject(img.height);
			img.loadPixels();
			os.writeObject(img.pixels);
			os.writeObject(depthMap);
			os.writeObject(realWorldMap_back);

			int i=0;
			for (DT line : lines) {
				if (line.getSaveMode()==-1)continue;
				i++;
			}
			os.writeObject(i);
			println(i);
			i=0;
			for (DT line : lines) {
				//\u30bf\u30a4\u30d7(line or spray)//
				int n=line.getSaveMode();
				if (n==-1)continue;
				os.writeObject(n);
				//\u30bf\u30a4\u30d7//
				os.writeObject(line.getColor());//\u8272
				os.writeObject(line.getWeight());//\u592a\u3055
				ArrayList<PVector>l=new ArrayList<PVector>();
				l.addAll(line);
				os.writeObject(l);//\u7dda\u30c7\u30fc\u30bf
				i++;
			}
			println(i);
			os.close();//\u4f7f\u3044\u7d42\u308f\u3063\u305f\u3089\u9589\u3081\u308b

			//\u753b\u50cf\u3082\u4fdd\u5b58\u3059\u308b
			img.save(path+".png");
		}
		catch(Exception e) {
			System.err.println("\u66f8\u304d\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
			e.printStackTrace();
		}
	}


	private void saveSketch() {//\u73fe\u5728\u958b\u3044\u3066\u3044\u308b\u30b9\u30b1\u30c3\u30c1\u3092\u81ea\u52d5\u4fdd\u5b58
		frame.setTitle("\u30b9\u30b1\u30c3\u30c1\u4fdd\u5b58\u4e2d");
		try {
			String Savepath2=Savepath+year()+month()+day()+"_"+hour()+minute()+second()+".dsd";//\u30d5\u30a1\u30a4\u30eb\u540d\u306b\u65e5\u4ed8\u3068\u6642\u9593\u3092\u8ffd\u52a0
			String path=Savepath2;
			println(path);

			ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream(new File(path)));
			println("\u4fdd\u5b58-path"+path);

			//\u30d5\u30a1\u30a4\u30eb\u306b\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u3092\u66f8\u304d\u8fbc\u3080
			os.writeObject(img.width);
			os.writeObject(img.height);
			img.loadPixels();
			os.writeObject(img.pixels);
			os.writeObject(depthMap);
			os.writeObject(realWorldMap_back);

			int i=0;
			for (DT line : lines) {
				if (line.getSaveMode()==-1)continue;
				i++;
			}
			os.writeObject(i);
			println(i);
			i=0;
			for (DT line : lines) {
				//\u30bf\u30a4\u30d7(line or spray)//
				int n=line.getSaveMode();
				if (n==-1)continue;
				os.writeObject(n);
				//\u30bf\u30a4\u30d7//
				os.writeObject(line.getColor());//\u8272
				os.writeObject(line.getWeight());//\u592a\u3055
				ArrayList<PVector>l=new ArrayList<PVector>();
				l.addAll(line);
				os.writeObject(l);//\u7dda\u30c7\u30fc\u30bf
				i++;
			}
			println(i);
			os.close();//\u4f7f\u3044\u7d42\u308f\u3063\u305f\u3089\u9589\u3081\u308b

			//\u73fe\u5728\u306e\u753b\u9762\u3082\u4fdd\u5b58\u3059\u308b
			saveFrame(path+".png");
		}
		catch(Exception e) {
			System.err.println("\u66f8\u304d\u8fbc\u307f\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
			e.printStackTrace();
		}
	}

	private void saveJsonData() {//\u73fe\u5728\u958b\u3044\u3066\u3044\u308b\u30b9\u30b1\u30c3\u30c1\u306e\u30c7\u30fc\u30bf\u3092json\u5f62\u5f0f\u3067\u4fdd\u5b58

		JSONObject json;
		json = new JSONObject();

		json.setInt("id", 0);
		json.setInt("imageW", img.width);
		json.setInt("imageH", img.height);

		img.loadPixels();
		String pixelsStr = "";
		int dimension=img.width*img.height;
		for (int i=0; i<dimension; i++) {
			pixelsStr=pixelsStr+img.pixels[i]+" ";
			println(i);
		}
		json.setString("pixels", pixelsStr);
		json.setString("species", "Panthera leo");
		json.setString("name", "Lion");
		saveJSONObject(json, "data/JSONObject.json");
	}


	private void saveJsonArrayData() {//\u73fe\u5728\u958b\u3044\u3066\u3044\u308b\u30b9\u30b1\u30c3\u30c1\u306e\u30c7\u30fc\u30bf\u3092json\u5f62\u5f0f\u3067\u4fdd\u5b58
		//JsonObject\u3092\u305d\u308c\u305e\u308c\u4f5c\u6210\u3057\u3066\u3001JsonArrayObject\u3067\u7ba1\u7406\u3059\u308b
		String[] species = { 
			"Capra hircus", "Panthera pardus", "Equus zebra"
		};
		String[] names = { 
			"Goat", "Leopard", "Zebra"
		};

		JSONObject json;
		JSONArray values = new JSONArray();

		for (int i = 0; i < species.length; i++) {

			JSONObject animal = new JSONObject();

			animal.setInt("id", i);
			animal.setString("species", species[i]);
			animal.setString("name", names[i]);

			values.setJSONObject(i, animal);
		}

		json = new JSONObject();
		json.setJSONArray("animals", values);

		saveJSONObject(json, "data/JSONArray.json");
	}


	public PVector calcRealPoint(float z, float x, float y) {//\u79fb\u52d5\u91cf0\u306e\u6642\u306e\u307fZ\u8ddd\u96e2\u3092\u8a08\u7b97\u3067\u304d\u308b\u95a2\u6570
		float mag=2*z/LENGTH;
		x=(x-img.width/2)*mag;
		y=(img.height/2-y)*mag;
		return new PVector(x, y, z);
	}



	public float myScreenZ(float x, float y, float z) {//\u30b9\u30af\u30ea\u30fc\u30f3\u304b\u3089\u306eZ\u6559\u7406\u3092\u6c42\u3081\u3088\u3046\u3068\u3057\u3066\u307f\u305f\u3084\u3064\u3002\u3046\u307e\u304f\u3044\u3063\u3066\u306a\u3044\u3002
		float xx, yy, zz;
		x+=pos.x;
		y+=pos.y;
		z+=pos.z;
		z+=-1000;
		x*=0.575f*width/img.width;
		y*=0.575f*width/img.width;
		z*=0.575f*width/img.width;
		xx=x*cos(rotY)-z*sin(rotY);
		zz=x*sin(rotY)+z*cos(rotY);
		x=xx;
		z=zz;
		yy=y*cos(rotX)-z*sin(rotX);
		zz=y*sin(rotX)+z*cos(rotX);
		z=zz;
		return -z+1200-150;
	}

	private PVector reCalcPoint(PVector recalcP) {//todo \u56de\u8ee2\u5f8c\u306b\u3064\u3058\u3064\u307e\u304c\u3042\u3046\u3088\u3046\u306b\u518d\u8a08\u7b97\u3059\u308b
		PVector ans=new PVector();

		//\u5e73\u884c\u79fb\u52d5 oK
		ans.x=recalcP.x-pos.x;
		ans.y=recalcP.y-pos.y;
		ans.z=recalcP.z-pos.z;
		//\u56de\u8ee2
		//setRotateMatrixX(cos(radians(rotX)), sin(radians(rotX)), 0, 0, -sin(radians(rotX)), cos(radians(rotX)), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);//Z\u8ef8\u65b9\u5411\u3067\u56de\u8ee2\u3059\u308b
		//ans.set(calcRotateX(ans));
		//X\u8ef8

		setRotateMatrix(
			1, 0, 0, 0, 
			0, cos(radians(rotX)), sin(radians(rotX)), 0, 
			0, -sin(radians(rotX)), cos(radians(rotX)), 0, 
			0, 0, 0, 1);//X\u8ef8\u65b9\u5411\u3067\u56de\u8ee2\u3059\u308b

		//ans.set(calcRotateX(ans));
		//Y\u8ef8
		setRotateMatrix(cos(radians(rotY)), 0, - sin(radians(rotY)), 0, 0, 1, 0, 0, sin(radians(rotY)), 0, cos(radians(rotY)), 0, 0, 0, 0, 1);//X\u8ef8\u65b9\u5411\u3067\u56de\u8ee2\u3059\u308b
		//ans.set(calcRotateX(ans));
		//Z\u8ef8
		setRotateMatrix(cos(radians(rotZ)), sin(radians(rotZ)), 0, 0, -sin(radians(rotZ)), cos(radians(rotZ)), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);//X\u8ef8\u65b9\u5411\u3067\u56de\u8ee2\u3059\u308b
		//ans.set(calcRotateX(ans));
		return ans;
	}

	private PVector calcRotateX(PVector p) {
		//\u4e0e\u3048\u3089\u308c\u305f\u70b9\u3092\u56de\u8ee2\u3057\u3066\u3001\u79fb\u52d5\u5f8c\u306e\u4f4d\u7f6e\u3092\u8fd4\u3059
		PVector calcP=new PVector();//\u8fd4\u3059\u7528
		//\u30d9\u30af\u30c8\u30ebp\u306f(p.x,p.y,p.z,1)\u3068\u3057\u3066\u8a08\u7b97\u3059\u308b
		calcP.x=p.x*RotateMatrix[0]+p.y*RotateMatrix[4]+p.z*RotateMatrix[8]+1*RotateMatrix[12];//x\u5ea7\u6a19
		calcP.y=p.x*RotateMatrix[1]+p.y*RotateMatrix[5]+p.z*RotateMatrix[9]+1*RotateMatrix[13];//y\u5ea7\u6a19
		calcP.z=p.x*RotateMatrix[2]+p.y*RotateMatrix[6]+p.z*RotateMatrix[10]+1*RotateMatrix[14];//y\u5ea7\u6a19
		return calcP;
	}

	private void setRotateMatrix(
		float m00, float m01, float m02, float m03, 
		float m10, float m11, float m12, float m13, 
		float m20, float m21, float m22, float m23, 
		float m30, float m31, float m32, float m33) {

		//\u79fb\u52d5\u7528\u306e\u914d\u5217\u3092\u4f5c\u308b
		RotateMatrix[0]=m00;
		RotateMatrix[1]=m01;
		RotateMatrix[2]=m02;
		RotateMatrix[3]=m03;

		RotateMatrix[4]=m10;
		RotateMatrix[5]=m11;
		RotateMatrix[6]=m12;
		RotateMatrix[7]=m13;

		RotateMatrix[8]=m20;
		RotateMatrix[9]=m21;
		RotateMatrix[10]=m22;
		RotateMatrix[11]=m23;

		RotateMatrix[12]=m30;
		RotateMatrix[13]=m31;
		RotateMatrix[14]=m32;
		RotateMatrix[15]=m33;
	}


	public void printTR() {
		print("pos :"+pos);
		println(" rot"+rotX+" "+rotY+" "+rotZ);
	}
}

public boolean isCross(PVector s1, PVector v1, PVector s2, PVector v2) {//\u59cb\u70b9s,\u65b9\u5411v\u306e\u7dda\u5206\u3068\u7dda\u5206\u304c\u4ea4\u5dee\u3057\u3066\u3044\u308b\u304b
	float cross=get_cross(v1, v2);
	if (cross==0)return false;
	PVector v=new PVector(s2.x-s1.x, s2.y-s1.y);
	float t1=get_cross(v, v1)/cross;
	float t2=get_cross(v, v2)/cross;
	return 0<=t1&&t1<=1&&0<=t2&&t2<=1;
}

public float get_cross(PVector p1, PVector p2) {//\u5916\u7a4d\u3092\u53d6\u5f97
	return p1.x*p2.y-p2.x*p1.y;
}

public static FilenameFilter getFileExtensionFilter(String extension) {//\u62e1\u5f35\u5b50 extension \u3067 filter\u3059\u308b\u305f\u3081\u306e\u30af\u30e9\u30b9\u3002
	final String _extension = extension;  
	return new FilenameFilter() {  
		public boolean accept(File file, String name) {  
			boolean ret = name.endsWith(_extension);   
			return ret;
		}
	};
}

/****************** \u30e2\u30c7\u30eb\u5ea7\u6a19-\u30b9\u30af\u30ea\u30fc\u30f3\u5ea7\u6a19 *****************
 / projectScreen,unprojectScreen\u306bPVector\u3092\u306a\u3052\u308b\u3068\u3001\u305d\u308c\u305e\u308c\u5909\u63db\u3059\u308b
 ****************************************************************/
// \u30e2\u30c7\u30eb\u5ea7\u6a19\u3092\u30b9\u30af\u30ea\u30fc\u30f3\u5ea7\u6a19\u306b\u5909\u63db
public PVector projectScreen(PVector v) {
	PMatrix3D m = getModelToScreenMatrix();//\u5909\u63db\u884c\u5217
	PVector p=new PVector();
	p.set(matrixCMult(m, v));

	//y\u8ef8\u65b9\u5411\u3067\u5909\u63db\u3059\u308b\u3061\u304b\u3089\u308f\u3056
	p.y=height-p.y;

	return p;
}

// \u884c\u5217\u3067\u5909\u63db\u3057\u305f\u30d9\u30af\u30c8\u30eb(w\u3067\u5272\u3063\u305f\u3082\u306e)\u3092\u8fd4\u3059
public PVector matrixCMult(PMatrix3D m, PVector v) {
	PVector ov = new PVector();
	ov.x = m.m00*v.x + m.m01*v.y + m.m02*v.z + m.m03;
	ov.y = m.m10*v.x + m.m11*v.y + m.m12*v.z + m.m13;
	ov.z = m.m20*v.x + m.m21*v.y + m.m22*v.z + m.m23;
	float w = m.m30*v.x + m.m31*v.y + m.m32*v.z + m.m33;
	if (w!=0) ov.mult(1.0f / w);
	return ov;
}

// \u30e2\u30c7\u30eb\u5ea7\u6a19->\u30b9\u30af\u30ea\u30fc\u30f3\u5ea7\u6a19\u306e\u8a08\u7b97\u306b\u4f7f\u3046\u884c\u5217\u3092\u53d6\u5f97
public PMatrix3D getModelToScreenMatrix() {
	PGraphics3D p3d=(PGraphics3D)g;

	PMatrix3D projection = new PMatrix3D();
	projection = p3d.projection;//\u30d7\u30ed\u30b8\u30a7\u30af\u30b7\u30e7\u30f3\u884c\u5217\u3092\u53d6\u5f97

	PMatrix3D modelview = new PMatrix3D();
	modelview = p3d.modelview;//\u30e2\u30c7\u30eb\u30d3\u30e5\u30fc\u884c\u5217\u3092\u53d6\u5f97

	PMatrix3D viewport = new PMatrix3D();//\u30d3\u30e5\u30fc\u30dd\u30fc\u30c8\u884c\u5217\u3092\u53d6\u5f97
	viewport.m03 = viewport.m00 = width * 0.5f;//\u30ba\u30ec\u3092\u88dc\u6b63\u3059\u308b
	viewport.m13 = viewport.m11 = height * 0.5f;

	PMatrix3D m = new PMatrix3D(modelview);
	m.preApply(projection);
	m.preApply(viewport);
	//m.m11=-m.m11;
	return m;//\u3053\u306e\u884c\u5217\u3092\u304b\u3051\u308b\u3068\u5909\u63db\u3067\u304d\u308b\u3000\u30cf\u30ba
}

// \u30b9\u30af\u30ea\u30fc\u30f3\u5ea7\u6a19\u3092\u30e2\u30c7\u30eb\u5ea7\u6a19\u306b\u5909\u63db
public PVector unprojectScreen(PVector v) {
	PMatrix3D m = getModelToScreenMatrix();
	m.invert();

	PVector p=new PVector();
	p.set(matrixCMult(m, v));
	//y\u8ef8\u65b9\u5411\u3067\u5909\u63db\u3059\u308b\u3061\u304b\u3089\u308f\u3056
	p.y=height-p.y;

	return p;
}
public class DT extends ArrayList<PVector> {//Data
	private int c;//\u7dda\u306e\u8272
	private int w;//\u7dda\u306e\u592a\u3055
	public DT(int c, int w) {
		this.c=c;
		this.w=w;
	}

	public int beginShape() {//beginShape\u306e\u30e2\u30fc\u30c9\u3092return\u3059\u308b\u3002-1\u306e\u6642beginShape()\u305d\u308c\u4ee5\u5916\u306e\u6642\u306fbeginShape(\u8fd4\u308a\u5024)\u3068\u306a\u308b
		return -1;
	}
	public boolean ableDraw() {//\u63cf\u753b\u53ef\u80fd\u304b
		return size()>1;//\u7dda\u3092\u69cb\u6210\u3059\u308b\u305f\u3081\u306b\u306f2\u70b9\u4ee5\u4e0a\u5fc5\u8981
	}
	public boolean ableCut() {//\u5207\u65ad\u53ef\u80fd\u304b
		return size()>1;
	}
	public int getSaveMode() {//\u30bb\u30fc\u30d6\u3059\u308b\u969b\u306e\u3075\u308a\u756a\u53f7 Line(0) Spray(1) \u4fdd\u5b58\u3057\u306a\u3044(-1)
		return -1;
	}

	//\u5404\u7a2e\u30b2\u30c3\u30bf\u30fc\u3068\u30bb\u30c3\u30bf\u30fc
	public void setColor(int c) {
		this.c=c;
	}
	public void setWeight(int w) {
		this.w=w;
	}
	public void setData(int c, int w) {
		setColor(c);
		setWeight(w);
	}
	public int getColor() {
		return c;
	}
	public int getWeight() {
		return w;
	}
}

public class Cut extends DT {
	private int n;//\u4f55\u756a\u76ee\u306e\u5024\u3092\u30ab\u30c3\u30c8\u3057\u305f\u304b\u3002
	public Cut(int c, int w, int n) {
		super(c, w);
		this.n=n;
	}
	public int getN() {
		return n;
	}

	public boolean ableDraw() {//\u5358\u306a\u308b\u30c7\u30fc\u30bf\u306a\u306e\u3067\u7d76\u5bfe\u63cf\u753b,\u5207\u65ad\u3057\u306a\u3044
		return false;
	}
	public boolean ableCut() {
		return false;
	}
}

public class Spray extends DT {
	public Spray(int c, int w) {
		super(c, w);
	}
	public int beginShape() {
		return POINTS;
	}
	public boolean ableCut() {//\u30b9\u30d7\u30ec\u30fc\u306f\u7d76\u5bfe\u5207\u65ad\u3067\u304d\u306a\u3044
		return false;
	}
	public int getSaveMode() {
		return 1;
	}
}

public class Line extends DT implements Serializable {
	public Line(int c, int w) {
		super(c, w);
	}
	public int getSaveMode() {
		return 0;
	}
	PVector p1=new PVector();

	public boolean add(PVector p) {
		super.add(p);
		float px, py, pz;
		//\u5e73\u6ed1\u5316_smoothing 
		//\u3053\u308c\u306f\u30da\u30f3\u30e2\u30fc\u30c9\u306e\u5834\u5408\u306e\u307f\u52d5\u304b\u3057\u305f\u3044//\u30da\u30f3B\u306e\u6642\u3082\u3084\u308b
		if (tool.nowToolNumber==0||tool.nowToolNumber==1) {
			if (size()==3) {
				p1.set(get(size()-2));//p1\u306b\u4e8c\u756a\u76ee\u3092\u4fdd\u5b58\u3059\u308b

				//\u5e73\u5747\u3092\u53d6\u308b
				px=(get(size()-3).x+get(size()-1).x)/2;
				py=(get(size()-3).y+get(size()-1).y)/2;
				pz=(get(size()-3).z+get(size()-1).z)/2;

				get(size()-2).set(px, py, pz);//\u5024\u3092\u66f8\u304d\u63db\u3048\u308b
			} else if (size()>3) {
				//p1\u3092\u4f7f\u3063\u3066\u5148\u306b\u5e73\u5747\u3092\u3068\u308b
				px=(p1.x+get(size()-1).x)/2;//\u914d\u5217\u306e\u4e00\u756a\u6700\u5f8c\u306e\u70b9\u3068\u6bd4\u8f03
				py=(p1.y+get(size()-1).y)/2;
				pz=(p1.z+get(size()-1).z)/2;

				p1.set(get(size()-2));//p1\u306b\u65b0\u3057\u3044\u5024\u3092\u4fdd\u5b58\u3057\u3066\u304a\u304f
				get(size()-2).set(px, py, pz);//\u5024\u3092\u66f8\u304d\u63db\u3048\u308b
			}
		}

		return true;
	}
}



public class TakeShot {

	SimpleOpenNI context;

	TakeShot(UseShot u) {
		cameraAllow=true;

		context = new SimpleOpenNI(u);

		context.setMirror(false);//\u93e1\u3067\u306f\u8868\u793a\u3057\u306a\u3044

		if (context.enableDepth() == false) {//\u6df1\u5ea6\u30bb\u30f3\u30b5\u4f7f\u3048\u306a\u3044\u306a\u3089\u7d42\u4e86
			System.err.println("Can't open the depthMap, maybe the camera is not connected!");
			cameraAllow=false;
		}

		if (context.enableRGB() == false) {//RGB\u30ab\u30e1\u30e9\u4f7f\u3048\u306a\u3044\u306a\u3089\u7d42\u4e86
			System.err.println("Can't open the rgbMap, maybe the camera is not connected or there is no rgbSensor!");
			cameraAllow=false;
		}

		// align depth data to image data
		context.alternativeViewPointDepthToImage();
	}

	PImage img;//\u753b\u50cf
	int depthMap[];//\u6df1\u5ea6
	PVector[] realWorldMap;//\u753b\u9762\u4e0a\u306e\u70b9\u306e\u5b9f\u969b\u306e\u5ea7\u6a19
	boolean cameraAllow;

	//      new Thread(new Mes()).start();
	public class Mes implements Runnable {
		public void run() {
			javax.swing.JOptionPane.showMessageDialog(frame, "\u30de\u30a6\u30b9\u30af\u30ea\u30c3\u30af\u3067\u4fdd\u5b58\u3057\u307e\u3059");
		}
	}

	public void draw() {
		// update the cam
		context.update();

		//background(252, 251, 246);

		img = context.rgbImage();
		depthMap = context.depthMap();
		realWorldMap = context.depthMapRealWorld();
		hint(DISABLE_DEPTH_TEST);//\u4e8c\u6b21\u5143\u63cf\u753b\u30e2\u30fc\u30c9
		//\u534a\u900f\u660e\u306b\u3059\u308b
		tint(255, 120);
		//image(img, 0, 0, width, height);
		//\u900f\u660e\u5ea6\u3092\u5143\u306b\u623b\u3059
		tint(255, 255);

		//\u30de\u30a6\u30b9\u306e\u5834\u6240\u306e\u6df1\u5ea6\u30c7\u30fc\u30bf\u3092\u8868\u793a
		int mx=(int)map(mouseX, 0, width, 0, img.width);//\u30de\u30a6\u30b9\u306ex\u5ea7\u6a19\u3092\u30a4\u30e1\u30fc\u30b8\u753b\u50cf\u4e0a\u306e\u4f4d\u7f6e\u306b\u5909\u63db
		int my=(int)map(mouseY, 0, height, 0, img.height);//\u30de\u30a6\u30b9\u306ey\u5ea7\u6a19\u3092\u30a4\u30e1\u30fc\u30b8\u753b\u50cf\u4e0a\u306e\u4f4d\u7f6e\u306b\u5909\u63db

		int idx=mx+my*context.depthWidth();
		PVector v=realWorldMap[idx];
		//text(depthMap[idx]+"\n"+v.x+", "+v.y+", "+v.z, mouseX, mouseY);
		if (depthMap[idx]==0) {
			text(depthMap[idx], mouseX, mouseY);
		}
		//\u7279\u4f8b\u7684\u306buseshot\u306e\u7dda\u753b\u3092\u8868\u793a\u3059\u308b
		data.get(tool.nowDataNumber).d();
		hint(ENABLE_DEPTH_TEST);//\u7d42\u4e86
	}

	public void mousePressed() {//\u30af\u30ea\u30c3\u30af\u3067\u51fa\u529b\u4fdd\u5b58

		println("\u30af\u30ea\u30c3\u30af");
		if (tool.pointOver(mouseX, mouseY)) return;//\u30c4\u30fc\u30eb\u30d0\u30fc\u306b\u91cd\u306a\u3063\u3066\u306a\u3044\u306e\u306a\u3089\u64ae\u5f71\u3059\u308b
		if (mouseX<0||mouseY<0||mouseX>width||mouseY>height)return;
		String fn=dataPath("mito")+"/"+year()+""+nf(month(), 2, 0)+""+nf(day(), 2, 0);

		try {
			if (!new File(fn).exists())
				new File(fn).mkdir();
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		//save(fn);
		save();
		println("save photo");
	}

	//void save(String path) {
	public void save() {
		try {
			//File f=new File(path+"/"+hour()+"_"+minute()+"_"+second());//\u30d5\u30a1\u30a4\u30eb\u540d\u3092\u6642\u5206\u79d2\u306b\u3057\u3066\u4fdd\u5b58
			//println("\u4fdd\u5b58"+f);
			/*
      ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream(f));

       //\u30d5\u30a1\u30a4\u30eb\u306b\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u3092\u66f8\u304d\u8fbc\u3080
       os.writeObject(img.width);
       os.writeObject(img.height);
       os.writeObject(img.pixels);
       os.writeObject(depthMap);
       os.writeObject(realWorldMap);

       os.close();//\u4f7f\u3044\u7d42\u308f\u3063\u305f\u3089\u9589\u3081\u308b
       */

			//\u64ae\u3063\u305f\u3089\u3059\u3050\u306b\u8aad\u307f\u8fbc\u3093\u3067\u30b9\u30b1\u30c3\u30c1\u3078\u307e\u308f\u3059
			//data.add(new Data(f.getCanonicalPath()));//f\u306e\u30d5\u30a1\u30a4\u30eb\u30d1\u30b9\u3092string\u306b\u76f4\u3057\u3066data\u306badd\u3059\u308b
			//data.add(new Data(img, depthMap, realWorldMap));//\u65b0\u3057\u3044\u30c7\u30fc\u30bf\u3068\u3057\u3066\u4fdd\u5b58\u3059\u308b
			data.get(tool.nowDataNumber).cameraChangeUpdate(img, depthMap, realWorldMap);//\u65b0\u3057\u3044\u30c7\u30fc\u30bf\u3068\u3057\u3066\u66f4\u65b0\u3059\u308b

			if (data.size()>=2) {//\u30b5\u30a4\u30ba\u304c2\u4ee5\u4e0a\u306e\u6642\u306b\u306f\u30c7\u30d5\u30a9\u30eb\u30c8\u30c7\u30fc\u30bf\u306f\u524a\u9664\u3002
				for (int j=0; j<data.size (); j++)
					if (data.get(j).defaultData)
						data.remove(j--);
			}
			//tool.nowDataNumber=data.size()-1;
		}
		catch(Exception e) {
			//\u30d5\u30a1\u30a4\u30eb\u304c\u898b\u3064\u304b\u3089\u306a\u304b\u3063\u305f\u308a\u3001InputStream\u306e\u751f\u6210\u306b\u5931\u6557\u3057\u305f\u308a\u3001\u305d\u306e\u305f\u306e\u4f8b\u5916\u304c\u3042\u3063\u305f\u3089\u3001\u66f8\u304d\u51fa\u3057\u3092\u4e2d\u65ad\u3002
			e.printStackTrace();
		}
	}
}
//import java.applet.*;
//import java.awt.*;
public class Tool extends Button {//\u30c4\u30fc\u30eb\u30d0\u30fc,\u30dc\u30bf\u30f3\u3092extends\u3057\u3066\u308b\u306e\u306fmouseOver\u3092\u697d\u306b\u3068\u308b\u305f\u3081
	private Button moveBar;//\u30c9\u30e9\u30c3\u30b0\u3057\u3066\u30c4\u30fc\u30eb\u30d0\u30fc\u3092\u52d5\u304b\u3059\u305f\u3081\u306e\u30dc\u30bf\u30f3
	private ImButton[] editButton, colorButton, axisButton, toolButton, dataButton, fileButton, thicknessButton;//\u5404\u7a2e\u30dc\u30bf\u30f3
	private Im2Button toolButton_chg;//\u56de\u8ee2\u7528\u306e\u30dc\u30bf\u30f3
	private Im2Button chgButton;//\u64ae\u5f71\u63cf\u753b\u5207\u308a\u66ff\u3048\u30dc\u30bf\u30f3
	private Im2Button movButton;//\u52d5\u753b\u9759\u6b62\u753b\u306e\u5207\u308a\u66ff\u3048
	private ImButton resetMoveButton;//\u52d5\u304d\u306e\u5207\u308a\u66ff\u3048
	private ImButton animButton;//\u30b9\u30b1\u30c3\u30c1\u306e\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u30dc\u30bf\u30f3
	private ImButton chgCanvasButton;//\u30ad\u30e3\u30f3\u30d0\u30b9\u5909\u66f4\u30dc\u30bf\u30f3

	private RoundButton takeButton;//\u64ae\u5f71\u7528\u306e\u4e38\u30dc\u30bf\u30f3

	private int[] penColor;//\u30da\u30f3\u8272 \u30ed\u30fc\u30c9\u3057\u305f\u753b\u50cf\u30c7\u30fc\u30bf\u304b\u3089\u53d6\u5f97\u3059\u308b
	public int nowColorNumber, nowAxisNumber, nowToolNumber, nowDataNumber, nowThicknessNumber;//\u30dc\u30bf\u30f3\u306e\u9078\u629e\u72b6\u614b
	public boolean moveWriter;//\u5168\u4f53\u79fb\u52d5\u304b\u3069\u3046\u304b
	private boolean isDragged, isDragged2;//\u7121\u5370\u306fmoveBar\u304c\u30c9\u30e9\u30c3\u30b0\u3055\u308c\u3066\u3044\u308b\u304b.2\u306fthis\u304c\u30c9\u30e9\u30c3\u30b0\u3055\u308c\u3066\u3044\u308b\u304b
	private boolean animSketch;
	private float spoit;//\u6df1\u5ea6\u30b9\u30dd\u30a4\u30c8
	private int border=100;//\u88dc\u6b63\u30da\u30f3\u306e\u81ea\u52d5\u5883\u754c
	public PVector pos;
	public float rotX, rotY, rotZ;
	public int animMode;
	private boolean moveMode;//\u79fb\u52d5\u65b9\u6cd5,true\u306e\u3068\u304d\u306f\u56de\u8ee2\u79fb

	private int clicknum=0;//\u30af\u30ea\u30c3\u30af\u56de\u6570\u306e\u8a18\u9332

	private char keyConfig[];
	float Y;//\u30c4\u30fc\u30eb\u30d0\u30fc\u306e\u9ad8\u3055

	public Tool() {
		super(0, 0, 60, height);//\u5168\u4f53\u306e\u5927\u304d\u3055

		PImage g;
		//\u6700\u521d\u306b\u9078\u3093\u3067\u304a\u304f\u30dc\u30bf\u30f3
		nowColorNumber=0;
		nowAxisNumber=nowToolNumber=nowDataNumber=nowThicknessNumber=0;
		isDragged=isDragged2=moveWriter=false;

		editButton=new ImButton[2];
		colorButton=new ImButton[6];
		axisButton=new ImButton[2];
		toolButton=new ImButton[5];
		dataButton=new ImButton[2];
		fileButton=new ImButton[3];
		thicknessButton=new ImButton[2];

		penColor=new int[colorButton.length];
		pos=new PVector();
		rotX=rotY=rotZ=0;

		//\u521d\u671f\u8a2d\u5b9a\u5404\u7a2e
		moveBar=new Button(0, 0, getW(), 25);

		Y=moveBar.getH()+5;
		for (int i=0; i<editButton.length; i++) {
			g=loadImage("icon-e"+i+".png");
			editButton[i]=new ImButton(g, 6+26*PApplet.parseInt(i%2), 26*PApplet.parseInt(i/2)+Y, 24, 24);
		}

		//\u30ab\u30e9\u30fc\u30dc\u30bf\u30f3
		Y+=26*ceil(editButton.length/2.f)+13;
		for (int i=0; i<colorButton.length; i++) {
			g=loadImage("icon-c"+i+".png");
			penColor[i]=g.get(0, 0);
			colorButton[i]=new ImButton(g, 6+26*PApplet.parseInt(i%2), 26*PApplet.parseInt(i/2)+Y, 24, 24);
		}
		colorButton[0].setSelected(true);//\u521d\u671f\u72b6\u614b\u3067\u9078\u629e\u3059\u308b\u30dc\u30bf\u30f3

		Y+=26*ceil(colorButton.length/2.f)+13;

		//\u592a\u3055\u30dc\u30bf\u30f3
		for (int i=0; i<thicknessButton.length; i++) {
			g=loadImage("icon-thic"+(i)+".png");
			thicknessButton[i]=new ImButton(g, 6, 17*(i)+Y, 48, 15);
		}
		thicknessButton[0].setSelected(true);//\u521d\u671f\u72b6\u614b\u3067\u9078\u629e\u3059\u308b\u30dc\u30bf\u30f3    
		Y+=17*ceil(thicknessButton.length)+13; 

		//\u30c4\u30fc\u30eb\u30dc\u30bf\u30f3
		for (int i=0; i<toolButton.length; i++) {
			g=loadImage("icon-"+nf(i+3, 2, 0)+".png");
			if (i==3||i==4) {
				println(i+"\u30c4\u30fc\u30eb\u30d0\u30fc\u306e\u9699\u9593\u3092\u3046\u3081\u308b");
				toolButton[i]=new ImButton(g, 6, 50*(i-2)+Y, 48, 48);//\u753b\u50cf\u306e\u5909\u5316\u304c\u306a\u3044\u30dc\u30bf\u30f3
			} else {
				toolButton[i]=new ImButton(g, 6, 50*i+Y, 48, 48);
			}
			toolButton_chg =new Im2Button(loadImage("icon-07_1.png"), loadImage("icon-07.png"), 6, 50*(i-2)+Y, 48, 48);//\u753b\u50cf\u5909\u5316\u306e\u3042\u308b\u30dc\u30bf\u30f3
		}
		toolButton[0].setSelected(true);
		//Y+=50*toolButton.length+13;
		Y+=50*3+13;//\u30c4\u30fc\u30eb\u30d0\u30fc\u306e\u9699\u9593\u3092\u3046\u3081\u308b

		//\u56de\u8ee2\u7528YZ\u8ef8\u30dc\u30bf\u30f3
		for (int i=0; i<axisButton.length; i++) {
			g=loadImage("icon-xyz"+(i+1)+".png");
			axisButton[i]=new ImButton(g, 6+26*(i%2), 26*(i/2)+Y, 24, 24);
		}
		axisButton[0].setSelected(true);//\u521d\u671f\u72b6\u614b\u3067\u9078\u629e\u3059\u308b\u30dc\u30bf\u30f3
		Y+=26*ceil(axisButton.length/2.f)+13;
		Y+=26;

		for (int i=0; i<dataButton.length; i++) {
			g=loadImage("icon-m"+i+".png");
			dataButton[i]=new ImButton(g, 6+(getW()-18-6)*i, Y, 12, 24);
		}
		Y+=26*dataButton.length/2+13;
		for (int i=0; i<fileButton.length; i++) {
			g=loadImage("icon-f"+i+".png");
			fileButton[i]=new ImButton(g, 6+26*(i%2), 26*(i/2)+Y, 24, 24);
		}
		Y+=26*ceil(fileButton.length/2.f)+13;
		Y+=26;
		//\u64ae\u5f71\u5207\u308a\u66ff\u3048\u30dc\u30bf\u30f3
		chgButton=new Im2Button(loadImage("icon-cng1.png"), loadImage("icon-cng0.png"), 6, Y, 48, 24);
		movButton=new Im2Button(loadImage("icon-cng1.png"), loadImage("icon-cng0.png"), 6, Y, 48, 24);
		Y=Y+26+13;
		resetMoveButton=new ImButton(loadImage("icon-resetmov.png"), 6, Y, 48, 24);

		Y=Y+26+13;
		animButton=new ImButton(loadImage("icon-anim.png"), 6, Y, 48, 24);

		takeButton = new RoundButton(loadImage("icon-cng1.png"), width-20, 10, 150);

		Y=Y+26+13; 
		chgCanvasButton = new ImButton(loadImage("icon-anim.png"), 6, Y, 48, 24);

		String t[]=loadStrings("system.ini");
		keyConfig=t[0].toCharArray();//\u30ad\u30fc\u30b3\u30f3\u30d5\u30a3\u30b0\u306e\u8aad\u307f\u8fbc\u307f


		//\u6700\u521d\u3092\u9759\u6b62\u753b\u304b\u3089\u59cb\u3081\u308b\u304b\u3001\u52d5\u753b\u304b\u3089\u59cb\u3081\u308b\u304b
		movButton.no=true;
		toolButton_chg.no=true;

		moveMode=true;

		//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u306e\u521d\u671f\u8a2d\u5b9a
		animSketch=false;

		//\u4e0d\u53ef\u8996\u30dc\u30bf\u30f3\u306e\u8a2d\u5b9a
		toolButton[1].visibility=false;
		toolButton[2].visibility=false;
		//toolButton[3].visibility=false;//\u30b9\u30dd\u30a4\u30c8
		toolButton[4].visibility=false;

		//\u30dc\u30bf\u30f3\u306e\u67a0\u7dda\u306e\u8a2d\u5b9a
		//hideButtonLine
		//moveBar.hideButtonLine=true;
		for (int i=0; i<editButton.length; i++)
			editButton[i].hideButtonLine=true;
		for (int i=2; i<colorButton.length; i++)
			colorButton[i].hideButtonLine=true;
		for (int i=0; i<thicknessButton.length; i++)
			thicknessButton[i].hideButtonLine=true;

		//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u306e\u30e2\u30fc\u30c9\u3092\u8a2d\u5b9a
		animMode=1;
	}

	public void update() {
		super.update(mouseX-getX(), mouseY-getY());
		//\u30c4\u30fc\u30eb\u30d0\u30fc\u304c\u62bc\u3055\u308c\u305f\u6642\u306e\u51e6\u7406
		if (super.isReleased) {
			if (mouseY>Y&&isMouseOver) {//\u3082\u3057\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af\u306a\u3089\u3070
				println("\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af:number"+oldToolNumber);
				//        data.get(tool.nowDataNumber).changeDrawMode();
			}
		}

		//move\u30dc\u30bf\u30f3\u304c\u62bc\u3055\u308c\u305f\u6642\u306e\u51e6\u7406\u3068\u30c9\u30e9\u30c3\u30b0\u72b6\u614b\u66f4\u65b0\u51e6\u7406
		moveBar.update(mouseX-getX(), mouseY-getY());
		isDragged=moveBar.isPressed||isDragged;
		if (moveBar.isPressed&&mouseButton==RIGHT) {
			review();
		}
		if (moveBar.isReleased)
			isDragged=false;
		if (isDragged&&mouseX-pmouseX!=0)
			addPosition(mouseX-pmouseX, 0);
		isDragged2=isPressed||isDragged2;
		if (isReleased)
			isDragged2=false;

		//\u5404\u7a2e\u30dc\u30bf\u30f3\u304c\u62bc\u3055\u308c\u305f\u6642\u306e\u51e6\u7406
		for (int i=0; i<editButton.length; i++) {
			editButton[i].update(mouseX-getX(), mouseY-getY());
			if (editButton[i].isPressed) {
				editButton[i].setSelected(false);
				switch(i) {
					case 0://\u5143\u306b\u623b\u3059
						redo();
						break;
					case 1://\u3084\u308a\u306a\u304a\u3057
						//data.get(nowDataNumber).clear();//\u5168\u6d88\u53bb
						data.get(tool.nowDataNumber).undo();
						break;
				}
			}
		}
		for (int i=0; i<colorButton.length; i++) {
			colorButton[i].update(mouseX-getX(), mouseY-getY());
			if (colorButton[i].isPressed) {
				nowColorNumber=i;
				buttonSelect(colorButton, i);
			}
		}
		for (int i=0; i<thicknessButton.length; i++) {
			thicknessButton[i].update(mouseX-getX(), mouseY-getY());
			if (thicknessButton[i].isPressed) {
				nowThicknessNumber=i;
				buttonSelect(thicknessButton, i);
			}
		}
		for (int i=0; i<axisButton.length; i++) {
			axisButton[i].update(mouseX-getX(), mouseY-getY());
			if (axisButton[i].isPressed) {
				nowAxisNumber=i;
				buttonSelect(axisButton, i);
			}
		}
		//\u30c4\u30fc\u30eb\u30dc\u30bf\u30f3
		for (int i=0; i<toolButton.length; i++) {
			toolButton[i].update(mouseX-getX(), mouseY-getY());
			if (toolButton[i].isPressed) {
				clicknum=0;
				nowToolNumber=i;
				//data.get(nowDataNumber).updateMap();//do
				buttonSelect(toolButton, i);
				toolButton_chg.setSelected(false);
			}
		}
		if (toolButton[3].isPressed) {
			spoit=0;
		}
		toolButton_chg.update(mouseX-getX(), mouseY-getY());
		if (toolButton_chg.isPressed) {
			clicknum++;//\u30af\u30ea\u30c3\u30af\u56de\u6570\u3092\u8a18\u9332
			if (nowToolNumber!=1) { 
				if (clicknum>1) {//\u30c0\u30d6\u30eb\u30af\u30ea\u30c3\u30af\u304a\u304d\u306b\u5909\u66f4\u3059\u308b
					toolButton_chg.no=!toolButton_chg.no;
					moveMode=!moveMode;//\u79fb\u52d5\u65b9\u6cd5\u3092\u5909\u66f4\u3059\u308b
				}
			}
			toolButton_chg.setSelected(true);
			//moveWriter=!moveWriter;//\u5168\u4f53\u79fb\u52d5\u3001\u5e73\u884c\u79fb\u52d5
			nowToolNumber=4;
			//toolButton[0].setSelected(false);//\u73fe\u5728\u306e\u30dc\u30bf\u30f3\u306e\u9078\u629e\u3092\u89e3\u9664
			for (int i=0; i<toolButton.length; i++) {
				toolButton[i].setSelected(false);//\u4ed6\u306e\u30c4\u30fc\u30eb\u30dc\u30bf\u30f3\u306e\u9078\u629e\u3092\u89e3\u9664
			}
		}

		for (int i=0; i<dataButton.length; i++) {
			dataButton[i].update(mouseX-getX(), mouseY-getY());
			if (dataButton[i].isPressed) {
				dataButton[i].setSelected(false);
				nowDataNumber=nowDataNumber+(i*2-1);
				if (!moveWriter) {
					if (nowDataNumber==-1||nowDataNumber==data.size()) {//\u5168\u4f53\u79fb\u52d5\u306b\u306a\u308a\u305d\u3046
						moveWriter=true;
						nowDataNumber=nowDataNumber-(i*2-1);
					}
				} else {//\u5168\u4f53\u79fb\u52d5\u306e\u6642\u306f\u5de6\u53f3\u3069\u3061\u3089\u306b\u52d5\u3044\u3066\u3082\u5168\u4f53\u79fb\u52d5\u3067\u306a\u304f\u306a\u308b
					moveWriter=false;
				}
				nowDataNumber=(nowDataNumber+data.size())%data.size();
			}
		}
		for (int i=0; i<fileButton.length; i++) {
			fileButton[i].update(mouseX-getX(), mouseY-getY());
			if (fileButton[i].isPressed) {
				fileButton[i].setSelected(false);
				switch(i) {
					case 0://read
						Data d=new Data();
						if (d.loadAbled) {
							data.add(d);//\u30ed\u30fc\u30c9\u306b\u6210\u529f\u3057\u305f\u3068\u304d\u306e\u307f\u30ea\u30b9\u30c8\u306b\u8ffd\u52a0
							if (data.size()>=2) {//\u30b5\u30a4\u30ba\u304c2\u4ee5\u4e0a\u306e\u6642\u306b\u306f\u30c7\u30d5\u30a9\u30eb\u30c8\u30c7\u30fc\u30bf\u306f\u524a\u9664\u3002
								for (int j=0; j<data.size (); j++)
									if (data.get(j).defaultData)
										data.remove(j--);
							}
							nowDataNumber=data.size()-1;
						}
						break;
					case 1://write
						//data.get(nowDataNumber).save();
						//\u30aa\u30fc\u30c8\u30bb\u30fc\u30d6\u306b\u5909\u66f4
						print("\u30aa\u30fc\u30c8\u30bb\u30fc\u30d6");
						data.get(nowDataNumber).saveSketch();
						break;
					case 2://close
						data.remove(nowDataNumber);
						if (data.size()==0)
							data.add(new Data(true));
						if (nowDataNumber>=data.size())nowDataNumber--;
						break;
				}
				mousePressed=false;//mousePressed\u304ctrue\u306e\u307e\u307e\u306b\u306a\u3063\u3066\u3057\u307e\u3046\u306e\u3067\u5f37\u5236\u7684\u306btrue\u3092\u4ee3\u5165\u3002
			}
		}
		//chgButton.update(mouseX-getX(), mouseY-getY());
		movButton.update(mouseX-getX(), mouseY-getY());

		if (movButton.isPressed) {
			println("\u30ab\u30e1\u30e9-\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u5207\u308a\u66ff\u3048");
			movButton.setSelected(false);
			movButton.no=!movButton.no;

			println(movButton.no);
			if (movButton.no) {
				song.rewind();//reload to play
				song.play();//play SE
			}
			if (!movButton.no) movButton.setSelected(true);
			;//\u67a0\u7dda\u3092\u3064\u3051\u308b
			if (movButton.no) data.get(nowDataNumber).saveSketch();//\u81ea\u52d5\u4fdd\u5b58
			//\u5199\u771f\u3092\u3068\u3063\u305f\u3089\u30c4\u30fc\u30eb\u3092\u925b\u7b46\u306b\u5909\u66f4\u3059\u308b
			toolButton[nowToolNumber].setSelected(false);//\u73fe\u5728\u306e\u30dc\u30bf\u30f3\u306e\u9078\u629e\u3092\u89e3\u9664
			//\u79fb\u52d5\u30dc\u30bf\u30f3\u306e\u8868\u793a\u3092\u975e\u8868\u793a\u306b\u8a2d\u5b9a
			toolButton_chg.setSelected(false);
			nowToolNumber=0;//\u30c4\u30fc\u30eb\u3092\u925b\u7b46\u306b\u5909\u66f4
			toolButton[nowToolNumber].setSelected(true);//\u9078\u629e\u8868\u793a\u3092\u925b\u7b46\u306b\u5909\u66f4

			if (oldToolNumber==tool.nowToolNumber) {//\u3082\u3057\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af\u306a\u3089\u3070
				println("\u5207\u308a\u66ff\u3048\u30dc\u30bf\u30f3/\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af:number"+oldToolNumber);
			} else {
				UseShot.oldToolNumber=nowToolNumber;
			}
		}


		resetMoveButton.update(mouseX-getX(), mouseY-getY());
		if (resetMoveButton.isPressed) {
			println("\u30ea\u30bb\u30c3\u30c8\u30dc\u30bf\u30f3");
			if (!tool.moveWriter)
				data.get(tool.nowDataNumber).matrixReset();
			else
				tool.matrixReset();
			resetMoveButton.setSelected(false);
		}

		animButton.update(mouseX-getX(), mouseY-getY());
		if (animButton.isPressed) {
			println("\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u30dc\u30bf\u30f3"+animSketch);
			//animMode=0;\u73fe\u5728\u306e\u8868\u793a\u306b\u3042\u308f\u305b\u3066\u30e2\u30fc\u30c9\u3092\u5909\u3048\u308b
			animSketch=!animSketch;//\u62bc\u3055\u308c\u308b\u305f\u3073\u306b\u5207\u308a\u66ff\u3048
			if (animSketch) {//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u3092\u884c\u3063\u3066\u3044\u308b\u3068\u304d
				animButton.setSelected(true);//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u30dc\u30bf\u30f3\u3092
				moveWriter=true;//\u5168\u4f53\u79fb\u52d5\u3092ON\u306b\u3059\u308b
			} else {
				animButton.setSelected(false);
				moveWriter=false;//\u5168\u4f53\u79fb\u52d5\u3092OFF\u306b\u3059\u308b
			}
		}

		//\u64ae\u5f71\u30dc\u30bf\u30f3
		takeButton.update(mouseX-getX(), mouseY-getY());
		if (takeButton.isPressed) {

			takeButton.setSelected(false);
			println("clicked");

			//=====

			println("\u30ab\u30e1\u30e9-\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u5207\u308a\u66ff\u3048");
			movButton.setSelected(false);
			movButton.no=!movButton.no;
			println(movButton.no);
			if (movButton.no) {
				song.rewind();//reload to play
				song.play();//play SE
			}

			if (!movButton.no) movButton.setSelected(true);
			//\u67a0\u7dda\u3092\u3064\u3051\u308b
			if (movButton.no) data.get(nowDataNumber).saveSketch();//\u81ea\u52d5\u4fdd\u5b58
			//\u5199\u771f\u3092\u3068\u3063\u305f\u3089\u30c4\u30fc\u30eb\u3092\u925b\u7b46\u306b\u5909\u66f4\u3059\u308b
			toolButton[nowToolNumber].setSelected(false);//\u73fe\u5728\u306e\u30dc\u30bf\u30f3\u306e\u9078\u629e\u3092\u89e3\u9664
			//\u79fb\u52d5\u30dc\u30bf\u30f3\u306e\u8868\u793a\u3092\u975e\u8868\u793a\u306b\u8a2d\u5b9a
			toolButton_chg.setSelected(false);
			nowToolNumber=0;//\u30c4\u30fc\u30eb\u3092\u925b\u7b46\u306b\u5909\u66f4
			toolButton[nowToolNumber].setSelected(true);//\u9078\u629e\u8868\u793a\u3092\u925b\u7b46\u306b\u5909\u66f4


			if (oldToolNumber==tool.nowToolNumber) {//\u3082\u3057\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af\u306a\u3089\u3070
				println("\u5207\u308a\u66ff\u3048\u30dc\u30bf\u30f3/\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af:number"+oldToolNumber);
			} else {
				UseShot.oldToolNumber=nowToolNumber;
			}
		}
		chgCanvasButton.update(mouseX-getX(), mouseY-getY());
		if(chgCanvasButton.isPressed){
			println("\u30ad\u30e3\u30f3\u30d0\u30b9\u306e\u8868\u793a\u5207\u308a\u66ff\u3048");
			if (!tool.moveWriter)
				data.get(tool.nowDataNumber).changeDrawMode();
			else
				tool.matrixReset();
			chgCanvasButton.setSelected(false);


		}

	}

	public void draw() {
		hint(DISABLE_DEPTH_TEST);//\u4e8c\u6b21\u5143\u63cf\u753b\u30e2\u30fc\u30c9
		if (nowToolNumber==3) {//\u30b9\u30dd\u30a4\u30c8\u306e\u8868\u793a
			fill(255);
			rect(mouseX, mouseY, 100, 20);
			fill(0);
			textAlign(CENTER, CENTER);
			text(spoit, mouseX+50, mouseY+10);
		}

		//this=\u30c4\u30fc\u30eb\u30d0\u30fc\u306e\u63cf\u753b
		stroke(0);
		fill(255);
		rect(getX(), getY(), getW(), getH());

		//move\u91cf\u306e\u53cd\u6620
		pushMatrix();
		translate(getX(), 0);

		//moveBar\u306e\u63cf\u753b
		fill(0xffeeeeee);
		rect(moveBar.getX(), moveBar.getY(), moveBar.getW(), moveBar.getH());

		//\u5404\u7a2e\u30dc\u30bf\u30f3\u63cf\u753b
		for (int i=0; i<editButton.length; i++)
			editButton[i].draw(mouseX-getX(), mouseY-getY());
		for (int i=0; i<colorButton.length; i++)
			colorButton[i].draw(mouseX-getX(), mouseY-getY());
		for (int i=0; i<thicknessButton.length; i++)
			thicknessButton[i].draw(mouseX-getX(), mouseY-getY());
		for (int i=0; i<axisButton.length; i++)
			axisButton[i].draw(mouseX-getX(), mouseY-getY());
		for (int i=0; i<toolButton.length; i++)
			toolButton[i].draw(mouseX-getX(), mouseY-getY());
		for (int i=0; i<dataButton.length; i++)
			dataButton[i].draw(mouseX-getX(), mouseY-getY());
		for (int i=0; i<fileButton.length; i++)
			fileButton[i].draw(mouseX-getX(), mouseY-getY());
		//chgButton.draw(mouseX-getX(), mouseY-getY());
		movButton.draw(mouseX-getX(), mouseY-getY());
		//chgButton2.draw(mouseX-getX(), mouseY-getY());
		resetMoveButton.draw(mouseX-getX(), mouseY-getY());
		animButton.draw(mouseX-getX(), mouseY-getY());
		toolButton_chg.draw(mouseX-getX(), mouseY-getY());
		takeButton.draw(mouseX-getX(), mouseY-getY());
		chgCanvasButton.draw(mouseX-getX(), mouseY-getY());

		fill(0);
		if (spoit!=0) {//\u30b9\u30dd\u30a4\u30c8\u304c0\u51fa\u306a\u3044\u6642\u30b9\u30dd\u30a4\u30c8\u91cf\u3092\u8868\u793a\u3059\u308b
			textAlign(CENTER, DOWN);
			text((int)spoit, toolButton[3].getX()+toolButton[3].getW()/2, toolButton[3].getY()+toolButton[3].getH());
		}

		//\u73fe\u5728\u64cd\u4f5c\u3057\u3066\u3044\u308b\u30c7\u30fc\u30bf\u306e\u756a\u53f7\u3092\u8868\u793a\u3059\u308b
		fill(moveWriter?0xffaaaaaa:0);
		textAlign(CENTER, CENTER);
		text(str(nowDataNumber), getW()/2, dataButton[0].getY()+dataButton[0].getH()/2);

		popMatrix();

		hint(ENABLE_DEPTH_TEST);//\u7d42\u4e86
	}

	private void buttonSelect(ImButton m[], int n) {//n\u756a\u76ee\u306e\u30dc\u30bf\u30f3\u3092\u9078\u629e\u3057n\u756a\u76ee\u4ee5\u5916\u306e\u30dc\u30bf\u30f3\u306e\u9078\u629e\u3092\u89e3\u9664\u3059\u308b
		for (int i=0; i<n; i++)
			m[i].setSelected(false);
		m[n].setSelected(true);
		for (int i=n+1; i<m.length; i++)
			m[i].setSelected(false);

		print("oldToolNumber :"+oldToolNumber);
		print("tool.nowToolNumber :"+tool.nowToolNumber);
		println("mouseY: "+mouseY+" Y: "+Y);

		if (oldToolNumber==tool.nowToolNumber) {//\u3082\u3057\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af\u306a\u3089\u3070
			println("\u8907\u6570\u56de\u30af\u30ea\u30c3\u30af:number"+oldToolNumber);
		} else {
			UseShot.oldToolNumber=nowToolNumber;
		}


		//\u5207\u308a\u66ff\u3048
		//println("\u5207\u308a\u66ff\u3048");
	}
	private void redo() {
		data.get(nowDataNumber).redo();
	}
	private void undo() {
		data.get(nowDataNumber).undo();
	}

	public void shortCut(int e) {//\u30b7\u30e7\u30fc\u30c8\u30ab\u30c3\u30c8\u30ad\u30fc
		if (e==keyConfig[0])
			redo();

		else if (e==keyConfig[1])
			undo();
		else if (e==keyConfig[2]);//\u62e1\u5927
		else if (e==keyConfig[3]);//\u7e2e\u5c0f
		else if (e==keyConfig[4]) {//\u30da\u30f3
			buttonSelect(toolButton, 0);
			nowToolNumber=0;
		} else if (e==keyConfig[5]) {//\u30ab\u30c3\u30bf\u30fc
			buttonSelect(toolButton, 2);
			nowToolNumber=2;
		} else if (e==keyConfig[6]) {//\u79fb\u52d5
			buttonSelect(toolButton, 4);
			nowToolNumber=4;
		}
	}

	public void review() {//\u7aef\u3063\u3053\u306b\u3042\u308f\u305b\u308b
		if (getX()+getW()/2<width/2)
			setPosition(0, 0);
		else
			setPosition(width-getW(), 0);
	}

	//\u5404\u7a2e\u30b2\u30c3\u30bf\u30fc\u3068\u30bb\u30c3\u30bf\u30fc
	public void setSpoit(float s) {
		spoit=s;
	}
	public float getSpoit() {
		return spoit;
	}
	public float getBorder() {
		return border;
	}
	public int getPenColor() {
		return penColor[nowColorNumber];
	}
	//int getPenWNum
	public int getPenColorNum() {//\u73fe\u5728\u306e\u30da\u30f3\u756a\u53f7\u3092\u8fd4\u3059
		return nowColorNumber;
	}
	public int getPenTool() {
		return nowToolNumber;
	}
	public int getPenWeight() {//\u30da\u30f3\u306e\u592a\u3055\u3092\u8fd4\u3059
		switch(nowThicknessNumber) {
			case 0:
				return 3;
			case 1:
				return 9;
		}
		//return 3;
		return UseShot.setLineW;//\u3053\u3053\u306f\u3044\u305a\u308c\u30dc\u30bf\u30f3?\u306a\u3069\u306e\u753b\u9762\u4e0a\u3067\u64cd\u4f5c\u3059\u308b\u6a5f\u80fd\u3068\u3057\u3066\u5b9f\u88c5\u3059\u308b
	}
	public boolean getMode() {//true\u3067UseMode,false\u3067TakeMode
		return chgButton.no;
	}
	public boolean getMovMode() {//true\u3067\u9759\u6b62\u753b\u30e2\u30fc\u30c9,false\u3067\u52d5\u753b\u30e2\u30fc\u30c9
		return movButton.no;
	}
	public boolean animMode() {//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u306e\u30e2\u30fc\u30c9
		return animSketch;
	}
	public boolean moveMode() {//\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3\u306e\u30e2\u30fc\u30c9
		return moveMode;
	}


	public int getThicknessNum() {//\u30da\u30f3\u306e\u592a\u3055
		return nowThicknessNumber;
	}

	public void matrixReset() {//\u79fb\u52d5\u91cf\u3092\u30ea\u30bb\u30c3\u30c8
		pos.set(0, 0, 0);
		rotX=rotY=rotZ=0;
	}
	public void setMatrix() {//\u79fb\u52d5\u91cf\u3092\u53cd\u6620
		rotateX(rotX);
		rotateY(rotY);
		rotateZ(rotZ);
		translate(pos.x, pos.y, pos.z);
	}
	public void rotate(float dx, float dy, float dz) {//\u56de\u8ee2\u3055\u305b\u308b
		rotX+=dy;
		rotY+=dx;
		rotZ+=dz;
	}
	public void move(float x, float y) {//\u79fb\u52d5\u3055\u305b\u308b
		switch(nowAxisNumber) {
			case 0:
				pos.x+=x*cos(rotY)+y*sin(rotY);
				pos.z+=x*sin(rotY)-y*cos(rotY);
				break;
			case 1:
				pos.x+=x*cos(rotY);
				pos.z+=x*sin(rotY);
				pos.y+=-y;
				break;
		}
	}
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "UseShot" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
